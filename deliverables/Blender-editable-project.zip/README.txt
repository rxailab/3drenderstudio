物影 Studio 场景工程
镜头：白底主图 / v2 / standard
原生文件：scene.blend
请保留同目录的 tex 纹理资源。scene.blend 为原始完整 Blender 场景。scene.json/FBX 为交换快照，不代替 C4D 原生工程。

转换注意事项：
Cinema 4D uses different material, light and color-management systems; visual parity requires review. The packed Blender file preserves the original render setup.
