"""Validated, replayable camera intent. No executable code is accepted from AI."""
import copy
import math

PRESETS = ['matte_plastic','glossy_plastic','painted_metal','brushed_metal','polished_metal','glass','rubber','fabric','leather','wood','ceramic']
LIGHTING_DEFAULTS = {'key_power':1,'fill_power':1,'rim_power':1,'environment':1}
TEXTURE_CHANNELS = {'base_color','roughness','metallic','normal','transmission'}

def default_plan():
    return dict(style='soft',aspect='1:1',margin=.12,rotation=[0,0,0],exposure=0,
        light_softness=1,lighting=copy.deepcopy(LIGHTING_DEFAULTS),texture_scale=1,texture_rotation=0,material_overrides=[],object_material_overrides=[],
        repair={'normals':False,'smooth':False},pose={},time_budget=1200,max_corrections=2,
        source='rules',visual_review=True,pending=['实际摆放方向与主展示面请在预览中确认'],shots=[
        dict(id='hero',label='白底主图',kind='full',azimuth=35,elevation=18,focal_length=70,style='white'),
        dict(id='campaign',label='棚拍宣传',kind='full',azimuth=-38,elevation=22,focal_length=60),
        dict(id='side',label='侧面结构',kind='full',azimuth=90,elevation=12,focal_length=70),
        dict(id='back',label='背面展示',kind='full',azimuth=155,elevation=22,focal_length=70),
        dict(id='detail1',label='材质细节',kind='detail',azimuth=30,elevation=25,focal_length=85),
        dict(id='detail2',label='结构细节',kind='detail',azimuth=-60,elevation=35,focal_length=85)])

def number(v, lo, hi, key):
    if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or not lo <= v <= hi:
        raise ValueError('%s 必须为 %s–%s 的有限数值' % (key,lo,hi))


def validate_lighting(value, key='lighting'):
    if not isinstance(value,dict) or set(value)-set(LIGHTING_DEFAULTS):
        raise ValueError(key+' 灯光倍率字段无效')
    for name, multiplier in value.items():
        number(multiplier,0 if name=='environment' else .1,3,key+'.'+name)


def validate_texture_override(material):
    """Validate data only; API callers also confine files to the project folder."""
    if 'textures' in material:
        textures=material['textures']
        if not isinstance(textures,dict) or set(textures)-TEXTURE_CHANNELS:
            raise ValueError('外部材质贴图通道无效')
        for path in textures.values():
            if not isinstance(path,str) or not path or len(path)>4096 or any(c in path for c in ('\x00','\n','\r')):
                raise ValueError('外部材质贴图路径无效')
            if path.lower().startswith(('http:','https:','file:','data:')):
                raise ValueError('外部贴图须先下载到当前项目')
    for key,limit in [('source',2048),('license',256)]:
        if key in material and (not isinstance(material[key],str) or len(material[key])>limit):
            raise ValueError('外部材质来源或许可无效')
    for key,lo,hi in [('texture_scale',.01,1000),('texture_rotation',-360,360)]:
        if key in material: number(material[key],lo,hi,key)
    if 'resource' in material:
        resource=material['resource']
        allowed={'provider','asset_id','name','url','license_url','resolution','downloaded_at','manifest_path'}
        if not isinstance(resource,dict) or set(resource)-allowed:
            raise ValueError('外部材质来源记录无效')
        for key,value in resource.items():
            if key=='downloaded_at': number(value,0,1e12,'downloaded_at')
            elif not isinstance(value,str) or len(value)>4096:
                raise ValueError('外部材质来源记录无效')

def validate(plan):
    p = copy.deepcopy(plan)
    for k, options in [('style',['white','soft','dark']),('aspect',['1:1','4:3','3:4'])]:
        if p.get(k) not in options: raise ValueError(k+' 不支持该选项')
    for k,lo,hi in [('margin',.03,.4),('exposure',-4,4),('light_softness',.25,4),('texture_scale',.01,1000),('texture_rotation',-360,360),('time_budget',10,14400),('max_corrections',0,2)]:
        number(p.get(k),lo,hi,k)
    if int(p['max_corrections']) != p['max_corrections']: raise ValueError('修正次数须为整数')
    if 'lighting' in p: validate_lighting(p['lighting'])
    if len(p.get('rotation',[])) != 3: raise ValueError('rotation 需要三个角度')
    for v in p['rotation']: number(v,-360,360,'rotation')
    if 'dimensions_mm' in p:
        if len(p['dimensions_mm'])!=3: raise ValueError('尺寸需要三个数值')
        for v in p['dimensions_mm']: number(v,.001,100000,'dimensions_mm')
    if not isinstance(p.get('repair'),dict) or any(type(v) is not bool for v in p['repair'].values()): raise ValueError('修复参数无效')
    shots = p.get('shots',[])
    if not 1 <= len(shots) <= 12 or len({s['id'] for s in shots}) != len(shots): raise ValueError('镜头数量或标识无效')
    for s in shots:
        if not str(s['id']).replace('_','').isalnum() or len(s['id'])>32: raise ValueError('镜头标识无效')
        if s['kind'] not in ['full','detail']: raise ValueError('镜头类型无效')
        for k,lo,hi in [('azimuth',-360,360),('elevation',-80,90),('focal_length',20,200)]: number(s.get(k),lo,hi,k)
    if type(p.get('visual_review',True)) is not bool: raise ValueError('视觉检查开关必须为布尔值')
    adjustments=p.get('shot_adjustments',{})
    if not isinstance(adjustments,dict): raise ValueError('镜头自动修正参数无效')
    for shot_id,adjustment in adjustments.items():
        if shot_id not in {s['id'] for s in shots} or not isinstance(adjustment,dict) or set(adjustment)-{'exposure_delta','softness_multiplier','lighting'}: raise ValueError('镜头自动修正引用或参数无效')
        if 'exposure_delta' in adjustment: number(adjustment['exposure_delta'],-4,4,'exposure_delta')
        if 'softness_multiplier' in adjustment: number(adjustment['softness_multiplier'],.0625,16,'softness_multiplier')
        if 'lighting' in adjustment: validate_lighting(adjustment['lighting'],'shot_adjustments.'+shot_id+'.lighting')
    for m in p.get('material_overrides',[]):
        validate_texture_override(m)
        if m.get('preset') not in PRESETS: raise ValueError('未知材质预设')
        if not isinstance(m.get('name'),str): raise ValueError('材质名缺失')
        for k in ['roughness','metallic','transmission']:
            if k in m: number(m[k],0,1,k)
        if 'color' in m:
            color=m['color']
            if isinstance(color,str):
                if len(color)!=7 or color[0]!='#': raise ValueError('颜色应为 #RRGGBB')
                int(color[1:],16)
            elif isinstance(color,list) and len(color) in (3,4):
                for v in color: number(v,0,1,'color')
            else: raise ValueError('颜色无效')
    local_materials=p.get('object_material_overrides',[])
    if not isinstance(local_materials,list) or len(local_materials)>1000: raise ValueError('局部材质参数无效')
    seen=set()
    for m in local_materials:
        if not isinstance(m,dict) or set(m)-{'object_name','material_name','preset','color','roughness','metallic','transmission','source','preserve_original','textures','license','resource','texture_scale','texture_rotation'}: raise ValueError('局部材质字段无效')
        validate_texture_override(m)
        if not all(isinstance(m.get(k),str) and m[k] for k in ['object_name','material_name']): raise ValueError('局部材质必须指定部件和材质名称')
        pair=(m['object_name'],m['material_name'])
        if pair in seen: raise ValueError('局部材质重复')
        seen.add(pair)
        if 'preset' in m and m['preset'] not in PRESETS: raise ValueError('未知局部材质预设')
        for k in ['roughness','metallic','transmission']:
            if k in m: number(m[k],0,1,k)
        if 'preserve_original' in m and type(m['preserve_original']) is not bool: raise ValueError('局部材质保留标记无效')
        if 'color' in m:
            color=m['color']
            if not isinstance(color,str) or len(color)!=7 or color[0]!='#': raise ValueError('局部颜色应为 #RRGGBB')
            int(color[1:],16)
    pose = p.get('pose',{})
    if not isinstance(pose,dict): raise ValueError('pose 无效')
    if 'frame' in pose: number(pose['frame'],0,100000,'frame')
    for k in ['rotation','translation']:
        if k in pose:
            if len(pose[k])!=3: raise ValueError('姿态需要三个坐标')
            for v in pose[k]: number(v,-1000,1000,k)
    return p

def enrich(plan, analysis):
    p=copy.deepcopy(plan)
    objects=[o for o in analysis.get('objects',[]) if o.get('type','MESH')=='MESH']
    if objects:
        p['shots'][-2]['target_object']=objects[0]['name']
        p['shots'][-1]['target_object']=objects[-1]['name']
    p['model_features']=analysis.get('features',{})
    p['material_suggestions']=analysis.get('materials',[])
    p['pending']=list(dict.fromkeys(p.get('pending',[])+analysis.get('warnings',[])))
    return validate(p)

def apply_material_note(plan, analysis, note):
    """Only act on unambiguous explicit material words; mixed notes need slot editing."""
    if not note: return plan
    p=copy.deepcopy(plan)
    words={'哑光塑料':'matte_plastic','亮面塑料':'glossy_plastic','喷涂金属':'painted_metal','拉丝金属':'brushed_metal','抛光金属':'polished_metal','玻璃':'glass','橡胶':'rubber','织物':'fabric','皮革':'leather','木材':'wood','陶瓷':'ceramic'}
    matches=[v for k,v in words.items() if k in note]
    if len(matches)==1:
        colors={'蓝色':'#366BA6','红色':'#B93832','黑色':'#15191E','白色':'#EAEAEA','绿色':'#366B55'}
        color=next((v for k,v in colors.items() if k in note),None)
        for material in analysis.get('materials',[]):
            m={'name':material['name'],'preset':matches[0],'source':'user','confidence':1.0}
            if color:m['color']=color
            p['material_overrides'].append(m)
        p['source']='user'
        p['pending'].append('已按明确材质说明应用预设；请检查各部件及原有标签')
    else:p['pending'].append('材质说明已保留，需在材质面板逐槽确认：'+note[:200])
    return validate(p)

def instruct(plan,text,analysis=None,image_path=None,selections=None):
    import ai_config
    import ai_client
    p=copy.deepcopy(plan)
    config=ai_config.get_config()
    if config.get('enabled') and config.get('api_key') and config.get('model'):
        try:
            p=validate(ai_client.request_plan(plan,text,analysis,config,image_path=image_path,selections=selections))
            diff=ai_client.parameter_diff(plan,p)
            if not diff: raise ValueError('AI 没有提出可执行的参数变化，请补充目标部件或具体调整要求。')
        except ValueError as exc:
            ai_config.record_result(config,False,str(exc))
            raise
        p['source']='ai'
        p['last_instruction']={'text':text,'changes':diff,'source':'ai','provider':config['provider'],'model':config['model'],'used_image':bool(image_path),'selections':copy.deepcopy(selections or [])}
        ai_config.record_result(config,True,'AI 已返回通过校验的摄影参数。')
        return p
    changes=[]
    rules=[(['柔和','柔一点'], 'light_softness',min(4,p['light_softness']*1.4)),
           (['增加留白','多点留白'], 'margin',min(.4,p['margin']+.05)),
           (['减少留白','放大产品'], 'margin',max(.03,p['margin']-.04)),
           (['亮一点','提亮'], 'exposure',min(4,p['exposure']+.35)),
           (['暗一点'], 'exposure',max(-4,p['exposure']-.35)),
           (['白底'], 'style','white'),(['深色','黑底'],'style','dark'),(['浅色'],'style','soft'),
           (['突出表面纹理','纹理明显'], 'light_softness',.65)]
    for words,key,value in rules:
        if any(w in text for w in words): p[key]=value;changes.append(key)
    if '俯拍' in text:
        for s in p['shots']: s['elevation']=80
        changes.append('shots.elevation')
    if '正面' in text:
        for s in p['shots']:
            if s['kind']=='full': s['azimuth']=0;s['elevation']=8
        changes.append('shots.azimuth/elevation')
    p['source']='rules'
    if not changes: raise ValueError('当前为内置规则模式，暂不理解此修改。可用：反光柔和一点、换成俯拍、突出表面纹理、增加留白、亮一点、白底、深色。也可直接调整参数。')
    p['last_instruction']={'text':text,'changes':changes,'parameter_diff':ai_client.parameter_diff(plan,p),'source':p['source']}
    return validate(p)
