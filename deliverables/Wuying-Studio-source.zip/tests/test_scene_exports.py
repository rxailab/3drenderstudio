import hashlib
import queue
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import studio_store as store
import scene_exports as scenes

class SceneExportTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.old_store=store.DATA;self.old_data=scenes.DATA;self.old_q=scenes.QUEUE
        store.DATA=self.root;scenes.DATA=self.root;scenes.QUEUE=queue.Queue()
        with store.connection() as c:c.execute('CREATE TABLE records (kind TEXT,id TEXT,payload TEXT,PRIMARY KEY(kind,id))')
        p=self.root/'fixture/runs/old/hero.blend';p.parent.mkdir(parents=True);p.write_bytes(b'BLENDER fixture unit test only')
        self.output=dict(job_id='old',shot_id='hero',shot_label='主图',quality='preview',version=1,blend_url='/files/fixture/runs/old/hero.blend')
        store.put('project',dict(id='fixture',version=99,outputs=[self.output]))
        self.body=dict(format='blend',output_id='old',shot_id='hero',quality='preview',version=1)

    def tearDown(self):
        store.DATA=self.old_store;scenes.DATA=self.old_data;scenes.QUEUE=self.old_q;self.tmp.cleanup()

    def test_snapshot_does_not_use_latest_plan(self):
        a=scenes.submit('fixture',self.body);b=scenes.submit('fixture',self.body)
        self.assertEqual(a['version'],1);self.assertEqual(a['id'],b['id']);self.assertEqual(scenes.QUEUE.qsize(),1)

    def test_no_client_file_path_or_unknown_snapshot(self):
        with self.assertRaises(ValueError):scenes.submit('fixture',{**self.body,'output_id':'not-real','source_blend':'C:/secret.blend'})

    def test_identical_file_in_another_revision_keeps_snapshot_identity(self):
        first=scenes.submit('fixture',self.body)
        p=store.get('project','fixture');p['outputs'].append({**self.output,'version':2});store.put('project',p)
        second=scenes.submit('fixture',{**self.body,'version':2})
        self.assertNotEqual(first['id'],second['id'])
        self.assertEqual(second['version'],2)

    def test_reject_source_outside_project(self):
        p=store.get('project','fixture');p['outputs'][0]['blend_url']='/files/../escape.blend';store.put('project',p)
        with self.assertRaises(ValueError):scenes.submit('fixture',self.body)

    def test_restart_and_cancellation(self):
        e=scenes.submit('fixture',self.body)
        with patch('scene_exports.threading.Thread'):scenes.start()
        self.assertEqual(store.get('export',e['id'])['status'],'interrupted')
        e=scenes.submit('fixture',self.body);scenes.stop(e['id']);scenes.update(e['id'],status='completed',native_url='fake.c4d')
        self.assertEqual(store.get('export',e['id'])['status'],'cancelled')

if __name__=='__main__':unittest.main()
