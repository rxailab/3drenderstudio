# 本地接口与可复现性

基础地址：`http://127.0.0.1:8765`。所有 JSON 使用 UTF-8。错误返回 `{ "error": "原因" }` 和非 2xx 状态码。

| 操作 | 接口 |
| --- | --- |
| 检查 Blender / AI / 设备 | `GET /api/system` |
| 项目列表 / 项目详情 | `GET /api/projects` / `GET /api/projects/{id}` |
| 上传 | `POST /api/projects`，multipart `files`、可选 `paths` JSON 数组、`name`、`dimensions` 毫米三元数组、`material_note`、`reference` |
| 修改方案 | `POST /api/projects/{id}/plan`，JSON 局部顶层更新 |
| 回退修改 | `POST /api/projects/{id}/undo` |
| 中文指令 | `POST /api/projects/{id}/instruct`，`{"text":"增加留白"}` |
| AI 服务设置 | `GET /api/ai/settings` / `PUT /api/ai/settings`；字段 `provider,base_url,model,enabled,api_key`；独立视觉字段为 `vision_provider,vision_base_url,vision_model,vision_enabled,vision_api_key`；空 Key 保留，分别用 `clear_key:true`、`vision_clear_key:true` 清除 |
| 真实连接测试 | `POST /api/ai/test`，仅测试已保存配置；返回 `success,message,settings`，无原始模型响应或密钥 |
| 真实视觉测试 | `POST /api/ai/vision/test`，使用最近的真实预览测试已保存视觉配置；无预览时明确失败，返回安全的可见内容描述和独立状态 |
| 图片表面多点定位 | `POST /api/projects/{id}/feedback/pick`；`output_id,shot_id,quality,version,points:[{id,x,y}]`，x/y 为图像内 0–1 坐标 |
| 局部视觉修改并预览 | `POST /api/projects/{id}/feedback`；同上加 `text`；再次验证真实表面，更新版本并提交该镜头的真实预览任务 |
| 直接修改 / 恢复所选材质 | `POST /api/projects/{id}/materials/selection/apply`；同上定位字段加 `patch` 或 `reset:true`，返回更新后的项目详情 |
| 已生成图片的逼真度诊断 | `POST /api/projects/{id}/review`；`output_id,shot_id,quality,version,question?`；当前版本的可执行反光建议可能自动提交预览，历史版本只诊断 |
| 创建任务 | `POST /api/projects/{id}/jobs`，`{"kind":"preview","quality":"preview","shot_ids":["hero"]}` |
| 任务状态 | `GET /api/jobs/{id}` |
| 取消 / 重试继续 | `POST /api/jobs/{id}/cancel` / `POST /api/jobs/{id}/retry` |
| 整组下载 | `GET /api/projects/{id}/bundle?blend=1&quality=all` |
| 样例 | `GET /api/examples`、`POST /api/examples/{id}/import` |
| 外部材质 | `POST /api/projects/{id}/materials/import`，multipart `name`、`preset`、`source`、`license` 和 `base_color/roughness/metallic/normal/transmission` 贴图 |
| 场景工程导出 | `POST /api/projects/{id}/exports`，JSON `format:blend/c4d`、`output_id:渲染任务ID`、`shot_id`、`quality`、`version` |
| 场景导出状态/取消 | `GET /api/exports/{id}` / `POST /api/exports/{id}/cancel` |

项目详情的 `exports` 包含独立场景导出任务。只有原生文件实际保存并重开成功时才返回 completed/native_url。C4D因授权失败时返回 failed/error，并可附带 `conversion_package_url`（兼容别名 `package_url`）下载手动转换资料；此包不是原生C4D工程。

正式任务使用 `kind=render`，`quality=standard` 或 `fine`。`shot_ids` 省略时使用全部镜头。提交可附带 `Idempotency-Key`，一个项目同时只允许一个活动任务。预览和正式任务使用同一计划；正式档位不把已有预览放大，而是重新原生渲染。

方案结构由 `planner.default_plan` 和 `planner.validate` 定义：风格、比例、留白、旋转、曝光、光源柔和度、纹理尺度/旋转、材质槽覆盖、部件局部覆盖 `object_material_overrides`、逐镜头调整 `shot_adjustments`、可回退修复、姿态、时间预算、自动检查 `visual_review`、修正次数、镜头数组和信息来源。每个镜头包含稳定 ID、名称、完整图/细节图类型、方位角、俯仰角、焦距和可选细节部件目标。当前状态操作支持给定部件旋转/位移与已有动画帧，不猜测机械运动。

## 部件材质接口

定位、编辑与诊断都用 `output_id`（渲染任务ID）、`shot_id`、`quality`、`version` 四项精确绑定已有图片。材质编辑仅允许当前方案版本，项目不可有排队或运行中的渲染任务；服务器根据坐标重新运行已保存场景的射线查询，不接受客户端提供的部件名称作为修改依据。

`feedback/pick` 的命中项包含 `object_name`、`material_name`、`slot_index` 和 `material_info`。后者包含可读的 `color,roughness,metallic,transmission,ior`，以及 `linked,textures,warnings,editable,supported,source,value_basis`。`source=rendered_scene` 表示来自保存场景。颜色以sRGB十六进制返回；贴图/节点驱动的通道值是输入默认值，不能当作点击位置的最终纹理颜色。未知值为 `null`，复杂着色器以 `editable:false` 和警告标记。

直接编辑请求示例：

```json
{
  "output_id": "渲染任务ID",
  "shot_id": "hero",
  "quality": "preview",
  "version": 3,
  "points": [{"id": "p1", "x": 0.42, "y": 0.56}],
  "patch": {"roughness": 0.5}
}
```

`patch` 仅允许 `preset,color,roughness,metallic,transmission`；后三项范围为0–1，预设必须属于内置预设。只改参数时保留未改的节点连接；显式改色会替换该通道连接。明确选择预设会替换着色器。复杂着色器在直接编辑与自然语言编辑中均须明确选择预设后才能替换，不能悄悄按普通Principled参数覆盖。

恢复请求使用 `reset:true` 代替 `patch`；它只删除所选网格/材质槽的局部覆盖，保留全局材质设置。成功编辑或恢复会记录 `material_edits`、递增版本并提交当前镜头的真实预览。无需外部AI即可调用直接编辑；若启用自动视觉检查且已配置Key，后续预览检查仍会调用AI。

## 图片逼真度诊断

`POST /review` 可分析历史版本图片。可选 `question` 默认为「为什么现在渲染得不够逼真？」，非空且不超过2000字。服务器读取该图真实PNG、成功的 `result.json` 和对应 `effective_plan` 或原始 `request.json`，文件或快照缺失时明确报错。

结果保存在匹配输出项的 `review`，包含 `source`（`ai` 或 `rules`）、`issues,patch,score,needs_user,status,checked_at,question`，以及自动材质需求 `material_requests`。真实AI成功时记录 `provider,model`；调用失败时设置 `ai_unavailable:true`，保留有限的基础测量结果并记录失败原因。逼真度报告结构为：

```json
{
  "realism": {
    "summary": "基于该图证据的概述",
    "causes": [{
      "aspect": "检查因素",
      "evidence": "具体可见区域、现象或实际测量；推测明确标记",
      "confidence": 0.8,
      "suggestion": "可实现的调整或需要人工确认的资料",
      "requires_user": true
    }],
    "priority_actions": ["优先处理事项"]
  }
}
```

诊断记录仍包含 `mode:diagnostic_only`、`parameter_changes_applied:false`，表示诊断本身没有修改参数；对当前方案版本的真实金属反光问题，服务可另行排队携带原问题的自动预览任务。历史图片、关闭自动修正或没有安全动作时只诊断。自动预览检查按配置上限尝试曝光、柔光和受限反射布光并比较真实渲染；图组完成后另由自动材质流程处理已校验的 `material_requests`。无Key时仅报告实际曝光/构图测量及未检查范围，不声称具有材质视觉理解。

## 诊断回复、生成方案与应用

`POST /api/projects/{id}/review/propose` 接收当前输出的 `output_id,shot_id,quality,version`，以及该诊断的 `review_checked_at`。`selected_causes` 为选中 `review.realism.causes` 的零起始索引；`answers` 为 `{index,status,text}` 数组，index引用`review.needs_user`，status支持`confirmed`、`answered`、`skipped`；`instruction`为不超过2000字的补充要求。确认仅认可问题，不授权猜测颜色或几何；answered需要实际文字。

返回`{proposal}`，含`id,source,base_version,status,summary,changes,needs_user,manual_actions,answers,can_apply`。`changes`列出参数path/before/after。生成方案保存回答与候选参数，不增加方案版本、不启动渲染；无可执行变化时can_apply为false。方案保存在项目的`review_proposals`中，重复同一请求复用结果。

`POST /api/projects/{id}/review/apply`仅接收`{"proposal_id":"已保存方案ID"}`。服务端验证图片、诊断指纹、计划指纹、当前版本和活动任务，再应用已保存候选方案，记录历史、增加版本并排队当前镜头真实预览。返回更新后的项目。浏览器不能用此接口直接注入候选参数；重复应用同一方案不再次改版或排队。诊断或计划变化后，未应用方案失效。

可批准的灯光参数为`lighting`倍率：`key_power,fill_power,rim_power`范围0.1–3，`environment`范围0–3，默认1。`shot_adjustments[shot_id].lighting`为该镜头的绝对倍率覆盖，优先于全局；曝光和柔光仍分别写入该镜头`exposure_delta`与`softness_multiplier`。倍率在材质适配布光完成后施加到真实灯光能量/物理环境强度，白底相机背景单独保持白色。自动逐镜头灯光修正仍仅使用曝光/柔光；同类材质微表面由下述独立流程处理。

## 联网材质代理

### 预览完成后的自动流程

真实预览任务完成后，服务器自动检查所选图组的AI诊断并排队材质任务，浏览器无需另发查找请求。只有 `source=ai` 的结构化需求可以触发，规则回退报告不触发。需求格式为：

```json
{
  "material_requests": [{
    "query": "fine cotton fabric",
    "targets": [{"object_name": "Bag body", "material_name": "Woven canvas"}],
    "reason": "包身缺少细密织物表面变化，现有材质名称明确为帆布；建议试用同类微表面。",
    "confidence": 0.5
  }]
}
```

最多2项需求，每项1–12个不重复的真实网格/材质对。`query` 是2–160字符的英文材质检索词，不接受URL、文件路径、代码或额外可执行字段。材质类别必须与服务器提供的明确依据一致；目标必须出现在当前图片的真实表面采样中，应用前再用保存场景的射线定位验证。默认猜测的材质类别、复杂着色器或已有外部资源的目标不可自动替换。

`confidence` 范围0–1，表示微表面不足对画面问题的可能贡献，用于记录与处理优先级，不设最低触发分数。符合已知材质类别、真实目标与格式约束的需求可以进行有次数上限的可回退试用，不能把推测写成已验证缺陷。目录选材还需另一次AI判断，匹配置信度至少0.6；AI不可用或退回关键词模式时自动任务停止。对于有可处理目标的新诊断，`material_requests` 必须显式返回，遗漏触发一次结构纠正；历史报告或无可处理目标时缺省按空数组处理。

自动任务记录 `origin:automatic`、`auto_query`、`expected_targets`、`chain`、原方案 `baseline_plan` 和原图组 `baseline_outputs`。`chain` 保存发起预览任务、已尝试目标、原选中镜头及当前轮次。自动应用固定 `use_base_color:false`，只下载/写入粗糙度与OpenGL法线通道，不改金属度、颜色、标签、预设或几何。每轮应用增加方案版本，并真实重渲染原选中图组。

材质链最多2轮，由发起任务的 `plan.max_corrections` 限制在0–2；它与逐镜头曝光修正分别计数。`visual_review:false` 或次数0时不启动。重复完成回调、同链已处理目标、已有外部贴图不会重复应用。下载前后都校验图片版本、方案指纹及活动任务；用户后续修改优先。

项目详情的 `auto_material` 提供 `origin_job_id,round,max_rounds,status,stage,error,updated_at`，可带 `task_id,notice,notes,comparison`。活动状态来自真实材质任务；结束状态还包括 `unchanged,disabled,skipped,reverted,needs_attention`。用同一服务/模型的完整前后图组AI平均评分比较，只有可比较且提高超过0.02时自动采纳。持平、下降、提高不超过0.02或评分不可比较时尝试恢复经文件校验的原图和原方案，新候选仍保留。新渲染失败时也尝试恢复；方案已被用户改动时不覆盖。任务记录真实的采用或恢复原因，不以下载完成宣称优化成功。`decision:reverted`、`restored_version`、`auto_finalized` 保存采纳/恢复结果，重启时恢复任务关联和未完成的比较。

### 可选的高级手动接口

`POST /api/projects/{id}/material-agent/tasks` 接收 `{output_id,shot_id,quality,version,points:[{id,x,y}],prompt,use_base_color:false}`，x/y为图片内归一化坐标。返回任务对象和202；相同当前图片、选点、要求和颜色选项的活动或完成请求会复用，避免重复应用。每个项目最多一个活动材质任务。

`GET /api/projects/{id}/material-agent/tasks` 返回该项目最近30个任务；`GET .../tasks/{task_id}` 返回单个任务；`POST .../tasks/{task_id}/cancel` 取消查找下载或关联的真实渲染。任务状态为`queued/running/rendering/completed/failed/cancelled/interrupted`，`stage`是实际步骤，包含`source,targets,selection,downloaded_files,error`；应用后增加`job_id,applied_version`。`completed`仅由真实渲染完成触发。取消不会回退已经应用的材质，重启会明确标记中断或恢复任务关联。

手动入口可在AI不可用时采用明确材质关键词匹配，且展示规则来源；自动入口不采用此回退。手动默认可应用粗糙度、OpenGL法线及可用金属度通道，`use_base_color`默认false；只有显式true才替换颜色。

两种流程的资源来源都限定Poly Haven，记录CC0许可和官方资源链接，联网请求使用独立User-Agent。只允许官方API和贴图主机、HTTPS、无重定向，下载1K PNG/JPG通道并核对官方大小、可用MD5、SHA256和解码尺寸。每张上限16MB。模型返回只可选择目录内实际ID，不能指定下载URL或执行代码。

局部覆盖`object_material_overrides`可记录`textures,source,license,resource,texture_scale,texture_rotation`。`resource`保存`provider,asset_id,name,url,license_url,resolution,downloaded_at,manifest_path`。API同时约束全局/局部贴图必须在当前项目materials目录。工作场景记录实际应用与跳过通道，.blend打包图片；整组下载包含当前材质资源、manifest及材质任务记录。

每个任务都有独立 `runs/{job_id}/`，保存 `request.json`、`result.json`、Blender 日志和渲染文件。`request.json` 是执行层收到的完整快照。对单个请求可直接运行：

```powershell
& 'D:\blender\blender.exe' -b --factory-startup --disable-autoexec --python-exit-code 1 --python blender/worker.py -- '<request.json 的绝对路径>'
```

工程文件是方便在 Blender 中继续编辑的副本；源模型始终在 `originals/` 中。手动修改或删除 `data/` 会破坏任务可追溯性，请在应用关闭后备份整个目录。此服务仅面向可信的本机用户，未设计多用户认证或公网部署。
