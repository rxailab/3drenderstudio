"""物影 Studio: local-only Blender product photography application."""
import io
import json
import os
import re
import shutil
import struct
import time
import uuid
import zipfile
from urllib.parse import unquote
from pathlib import Path, PurePosixPath
from flask import Flask,request,jsonify,send_from_directory,send_file,abort
from werkzeug.exceptions import HTTPException
from studio_store import ROOT,DATA,LOCK,get,put,all_records,atomic_json

env=ROOT/'.env'
if env.exists():
    for line in env.read_text(encoding='utf-8-sig').splitlines():
        if '=' in line and not line.lstrip().startswith('#'):
            k,v=line.split('=',1);os.environ.setdefault(k.strip(),v.strip().strip('"'))

import engine
import scene_exports
import ai_config
from planner import default_plan,validate,instruct,PRESETS
app=Flask(__name__,static_folder='static')
app.config['MAX_CONTENT_LENGTH']=512*1024*1024
ALLOWED={'.obj','.mtl','.glb','.png','.jpg','.jpeg','.webp','.tga','.bmp','.tif','.tiff','.exr','.hdr','.json','.txt'}

@app.errorhandler(Exception)
def error(exc):
    if isinstance(exc,HTTPException): return jsonify(error=exc.description),exc.code
    if isinstance(exc,KeyError): return jsonify(error='记录不存在'),404
    if isinstance(exc,(ValueError,TypeError)): return jsonify(error=str(exc)),400
    app.logger.exception('request failed')
    return jsonify(error=str(exc)),500

@app.before_request
def local_guard():
    # Bound to loopback; additionally reject cross-site browser writes / DNS rebinding.
    if request.host.split(':')[0] not in ['localhost','127.0.0.1','[::1]']: abort(403)
    origin=request.headers.get('Origin')
    if request.method not in ['GET','HEAD','OPTIONS'] and origin and origin not in ['http://'+request.host,'https://'+request.host]: abort(403)

@app.get('/')
def index(): return send_from_directory(ROOT/'static','index.html')

@app.get('/api/system')
def system():
    exe=engine.blender_path()
    ai=ai_config.public_config()
    return jsonify(blender=exe,available=bool(exe),ai_mode='ai' if ai['enabled'] and ai['key_configured'] and ai['model'] else 'rules',ai=ai,device=engine.DEVICE,presets=PRESETS,scene_exports=scene_exports.capabilities())

@app.route('/api/ai/settings',methods=['GET','PUT'])
def ai_settings():
    value=ai_config.save_config(request.get_json(force=True)) if request.method=='PUT' else ai_config.public_config()
    response=jsonify(value);response.headers['Cache-Control']='no-store'
    return response

@app.post('/api/ai/test')
def ai_test():
    from ai_client import test_connection
    config=ai_config.get_config()
    if not config['api_key'] or not config['model']:
        return jsonify(success=False,message='请先保存 Access Token 和模型 ID',settings=ai_config.public_config())
    try:
        result=test_connection(config)
        ai_config.record_result(config,True,result['message'])
        return jsonify(success=True,**result,settings=ai_config.public_config())
    except ValueError as exc:
        ai_config.record_result(config,False,str(exc))
        return jsonify(success=False,message=str(exc),settings=ai_config.public_config())

@app.post('/api/ai/vision/test')
def ai_vision_test():
    """Test visual understanding with an existing real preview, never an invented image."""
    from ai_client import test_vision_connection
    config=ai_config.get_vision_config()
    if not config.get('enabled') or not config.get('api_key') or not config.get('model'):
        return jsonify(success=False,message='请先配置视觉模型和可用的 Access Token',settings=ai_config.public_config())
    candidates=[]
    for project in all_records('project'):
        for output in project.get('outputs',[]):
            url=output.get('png_url','')
            if output.get('quality')!='preview' or not isinstance(url,str) or not url.startswith('/files/'): continue
            path=(DATA/url[7:]).resolve()
            if (DATA/project['id']).resolve() not in path.parents or not path.is_file(): continue
            candidates.append((output.get('created_at',0),path))
    if not candidates:
        return jsonify(success=False,message='请先生成一张真实预览，再测试视觉模型',settings=ai_config.public_config())
    try:
        path=max(candidates,key=lambda item:item[0])[1]
        engine.verify_image(path,'PNG')
        result=test_vision_connection(config,path)
        ai_config.record_vision_result(config,True,result['message'])
        return jsonify(success=True,**result,settings=ai_config.public_config())
    except (ValueError,RuntimeError,OSError) as exc:
        ai_config.record_vision_result(config,False,str(exc))
        return jsonify(success=False,message=str(exc),settings=ai_config.public_config())

@app.get('/api/projects')
def projects(): return jsonify(all_records('project'))

@app.get('/api/projects/<ident>')
def project(ident): return jsonify(engine.project_view(ident))

def safe_path(base,name):
    name=name.replace('\\','/')
    parts=PurePosixPath(name)
    if parts.is_absolute() or any(x in ('..','') for x in parts.parts) or ':' in name: raise ValueError('资源路径必须位于上传目录内')
    dest=(base/name).resolve()
    if base.resolve() not in dest.parents: raise ValueError('资源路径无效')
    if dest.suffix.lower() not in ALLOWED: raise ValueError('不支持资源格式：'+dest.suffix)
    dest.parent.mkdir(parents=True,exist_ok=True)
    if dest.exists(): raise ValueError('资源路径重复：'+name)
    return dest

def extract_archive(content,base):
    with zipfile.ZipFile(content) as z:
        entries=[i for i in z.infolist() if not i.is_dir()]
        if len(entries)>2000 or sum(i.file_size for i in entries)>1024**3: raise ValueError('ZIP 解压内容超过限制')
        for i in entries:
            if (i.external_attr >> 16) & 0o170000 == 0o120000: raise ValueError('不接受符号链接')
            safe_path(base,i.filename).write_bytes(z.read(i))

def check_resources(base):
    # Reject local absolute / parent references before Blender can read them.
    for f in list(base.rglob('*.obj'))+list(base.rglob('*.mtl')):
        for line in f.read_text(encoding='utf-8',errors='replace').splitlines():
            parts=line.strip().split(maxsplit=1)
            if len(parts)<2: continue
            key,value=parts
            if key.lower()=='mtllib' or key.lower().startswith('map_') or key.lower() in ['bump','disp','decal','norm']:
                value=value.replace('\\','/').strip('"')
                # Texture options remain legal; check every token for external paths.
                for token in value.split():
                    if token.startswith('/') or ':' in token: raise ValueError('OBJ/MTL 包含绝对资源路径，请改成相对路径')
                    if '..' in PurePosixPath(token).parts and base.resolve() not in (f.parent/token).resolve().parents: raise ValueError('贴图引用超出模型资源目录')
                if '..' in PurePosixPath(value).parts:
                    resolved=(f.parent/value).resolve()
                    if base.resolve() not in resolved.parents: raise ValueError('贴图引用超出模型资源目录')
    for f in base.rglob('*'):
        if f.suffix.lower()!='.glb': continue
        with f.open('rb') as stream:
            header=stream.read(20)
            if len(header)!=20 or header[:4]!=b'glTF': raise ValueError('GLB 文件头无效')
            length,kind=struct.unpack('<II',header[12:20])
            if kind!=0x4e4f534a or length>64*1024*1024: raise ValueError('GLB JSON 数据块无效或过大')
            document=json.loads(stream.read(length).decode('utf-8'))
            for item in document.get('images',[])+document.get('buffers',[]):
                uri=unquote(item.get('uri',''))
                if uri and not uri.startswith('data:'):
                    resolved=(f.parent/uri).resolve()
                    if ':' in uri or uri.startswith(('/', '\\')) or base.resolve() not in resolved.parents: raise ValueError('GLB 外部资源引用不安全')

def create_project(base,name='',metadata=None):
    models=list(base.rglob('*.glb'))+list(base.rglob('*.obj'))
    # Case-insensitive extension handling on Windows and Linux.
    models=list(dict.fromkeys(models+[p for p in base.rglob('*') if p.suffix.lower() in ['.glb','.obj']]))
    if len(models)!=1: raise ValueError('每个项目请上传一个 OBJ 或 GLB，配套贴图可放在同一 ZIP 中')
    check_resources(base)
    ident=base.parent.name;name=name.strip() or models[0].stem
    slug=re.sub(r'[^\w\-]+','_',name)[:60] or 'product'
    plan=default_plan()
    metadata=metadata or {}
    if metadata.get('dimensions'):
        value=metadata['dimensions']
        if isinstance(value,str):
            try: value=json.loads(value)
            except ValueError: value=[float(x) for x in re.split('[x×,， ]+',value) if x]
        if not isinstance(value,list) or len(value)!=3 or any(not isinstance(x,(int,float)) or x<=0 or x>100000 for x in value): raise ValueError('真实尺寸应为三个正数（毫米）')
        plan['dimensions_mm']=value
    p=dict(id=ident,name=name[:100],slug=slug,model_path=str(models[0]),status='analyzing',analysis=None,plan=plan,version=1,history=[],outputs=[],metadata=metadata,created_at=time.time())
    put('project',p);engine.submit(ident,'analyze');return engine.project_view(ident)

@app.post('/api/projects')
def upload():
    files=request.files.getlist('files')
    if not files: raise ValueError('请选择模型文件')
    ident=uuid.uuid4().hex;base=DATA/ident/'originals';base.mkdir(parents=True)
    paths=json.loads(request.form.get('paths','[]'))
    for i,f in enumerate(files):
        name=paths[i] if i<len(paths) else f.filename
        if Path(name).suffix.lower()=='.zip': extract_archive(f.stream,base)
        else: f.save(safe_path(base,name))
    reference=request.files.get('reference')
    metadata={k:request.form.get(k,'') for k in ['dimensions','material_note','product_category']}
    if reference:
        refdir=base.parent/'references';refdir.mkdir()
        path=safe_path(refdir,Path(reference.filename).name);reference.save(path);metadata['reference']=str(path)
        metadata['reference_status']='已保存供人工参考；当前不会自动从参考图识别材质'
    return jsonify(create_project(base,request.form.get('name',''),metadata)),201

@app.post('/api/projects/<ident>/plan')
def plan(ident):
    patch=request.get_json(force=True)
    if 'plan' in patch and isinstance(patch['plan'],dict): patch=patch['plan']
    with LOCK:
        p=get('project',ident);old=p['plan'];new={**old,**patch,'source':'user'};new=validate_project_plan(ident,new)
        p['history'].append({'version':p['version'],'plan':old,'at':time.time(),'reason':'界面参数修改'})
        p['plan']=new;p['version']+=1;put('project',p)
    return jsonify(engine.project_view(ident))

def validate_project_plan(ident,plan):
    plan=validate(plan)
    root=(DATA/ident/'materials').resolve()
    for m in plan.get('material_overrides',[])+plan.get('object_material_overrides',[]):
        for channel,path in m.get('textures',{}).items():
            if channel not in ['base_color','roughness','metallic','normal','transmission']: raise ValueError('未知 PBR 通道')
            resolved=Path(path).resolve()
            if root not in resolved.parents or not resolved.is_file(): raise ValueError('PBR 贴图必须先导入到当前项目')
    return plan

@app.post('/api/projects/<ident>/undo')
def undo(ident):
    with LOCK:
        p=get('project',ident)
        if not p['history']: raise ValueError('暂无可回退操作')
        p['plan']=p['history'].pop()['plan'];p['version']+=1;put('project',p)
    return jsonify(engine.project_view(ident))

@app.post('/api/projects/<ident>/materials/import')
def material_import(ident):
    p=get('project',ident)
    source=request.form.get('source','').strip();license_name=request.form.get('license','').strip()
    if not source or not license_name: raise ValueError('请填写材质来源和许可')
    name=request.form.get('name','').strip()
    if not name: raise ValueError('请选择要替换的材质槽')
    folder=DATA/ident/'materials'/uuid.uuid4().hex;folder.mkdir(parents=True)
    textures={}
    for channel in ['base_color','roughness','metallic','normal','transmission']:
        f=request.files.get(channel)
        if f:
            dest=safe_path(folder,channel+Path(f.filename).suffix.lower());f.save(dest)
            engine.verify_image(dest);textures[channel]=str(dest)
    if not textures: raise ValueError('请至少选择一张 PBR 贴图')
    new={**p['plan']};new['material_overrides']=[m for m in new['material_overrides'] if m['name']!=name]+[{'name':name,'preset':request.form.get('preset','matte_plastic'),'textures':textures,'source':source,'license':license_name}]
    with LOCK:
        p=get('project',ident);p['history'].append({'version':p['version'],'plan':p['plan'],'at':time.time(),'reason':'导入外部 PBR 材质'})
        p['plan']=validate(new);p['version']+=1;put('project',p)
    return jsonify(engine.project_view(ident))

@app.post('/api/projects/<ident>/instruct')
def instruction(ident):
    p=get('project',ident);text=request.get_json(force=True).get('text','')[:2000]
    new=validate_project_plan(ident,instruct(p['plan'],text,p.get('analysis')))
    with LOCK:
        current=get('project',ident)
        if current['version']!=p['version']: raise ValueError('方案已被其他操作修改，请重试')
        p=current
        p['history'].append({'version':p['version'],'plan':p['plan'],'at':time.time(),'reason':text});p['plan']=new;p['version']+=1;put('project',p)
    return jsonify(engine.project_view(ident))

@app.post('/api/projects/<ident>/feedback/pick')
def feedback_pick(ident):
    return jsonify(engine.pick_output(ident,request.get_json(force=True)))

@app.post('/api/projects/<ident>/materials/selection/apply')
def selected_material_apply(ident):
    from material_edit import apply_selection
    return jsonify(apply_selection(ident,request.get_json(force=True)))

@app.post('/api/projects/<ident>/material-agent/tasks')
def material_agent_create(ident):
    import material_agent
    return jsonify(material_agent.submit(ident,request.get_json(force=True))),202

@app.get('/api/projects/<ident>/material-agent/tasks')
def material_agent_list(ident):
    import material_agent
    return jsonify(material_agent.list_tasks(ident))

@app.get('/api/projects/<ident>/material-agent/tasks/<task_id>')
def material_agent_read(ident,task_id):
    import material_agent
    return jsonify(material_agent.get_task(ident,task_id))

@app.post('/api/projects/<ident>/material-agent/tasks/<task_id>/cancel')
def material_agent_cancel(ident,task_id):
    import material_agent
    return jsonify(material_agent.cancel(ident,task_id))

@app.post('/api/projects/<ident>/review')
def review_output(ident):
    return jsonify(engine.review_output(ident,request.get_json(force=True)))

@app.post('/api/projects/<ident>/review/propose')
def review_propose(ident):
    from review_actions import propose
    return jsonify(propose(ident,request.get_json(force=True)))

@app.post('/api/projects/<ident>/review/apply')
def review_apply(ident):
    from review_actions import apply
    return jsonify(apply(ident,request.get_json(force=True)))

@app.post('/api/projects/<ident>/feedback')
def feedback_apply(ident):
    body=request.get_json(force=True)
    text=body.get('text','')
    if not isinstance(text,str) or not text.strip() or len(text)>2000:
        raise ValueError('请用不超过 2000 字描述选中部位的问题')
    config=ai_config.get_config()
    if not config['enabled'] or not config['api_key'] or not config['model']:
        raise ValueError('多点视觉反馈需要先在“AI 设置”中填写 Access Token 和模型')
    p=get('project',ident)
    if body.get('version')!=p['version']:
        raise ValueError('这张图片不是当前方案版本，请先生成当前版本预览再点选修改')
    if any(j['project_id']==ident and j['status'] in ('queued','running') for j in all_records('job')):
        raise ValueError('请等待当前渲染结束，或先取消任务，再提交局部修改')
    matches=[o for o in p.get('outputs',[]) if all(o.get(k)==body.get(k) for k in ('shot_id','quality','version')) and o.get('job_id')==body.get('output_id')]
    if len(matches)!=1:
        raise ValueError('请选择一个已生成的镜头版本')
    output=matches[0]
    image_path=(DATA/output['png_url'][7:]).resolve()
    if (DATA/ident).resolve() not in image_path.parents or not image_path.is_file():
        raise ValueError('预览图片不存在，请重新生成')
    picked=engine.pick_output(ident,body)
    hits=picked['hits']
    if not hits or any(not hit.get('hit') for hit in hits):
        raise ValueError('部分位置没有命中产品，请移除背景上的点，再提交修改')
    new=validate_project_plan(ident,instruct(p['plan'],text.strip(),p.get('analysis'),image_path=image_path,selections=hits))
    old_local={(entry['object_name'],entry['material_name']):entry for entry in p['plan'].get('object_material_overrides',[])}
    new_local={(entry['object_name'],entry['material_name']):entry for entry in new.get('object_material_overrides',[])}
    for hit in hits:
        pair=(hit['object_name'],hit['material_name'])
        entry=new_local.get(pair)
        if hit.get('material_info',{}).get('editable') is False and entry!=old_local.get(pair):
            if entry and (not entry.get('preset') or entry.get('preserve_original',True)):
                raise ValueError('所选部件使用复杂材质节点，请先明确选择内置材质预设，再修改其表面参数')
    with LOCK:
        current=get('project',ident)
        if current['version']!=p['version']:
            raise ValueError('方案已被其他操作修改，未应用此次反馈，请刷新后重试')
        if any(j['project_id']==ident and j['status'] in ('queued','running') for j in all_records('job')):
            raise ValueError('已有渲染任务开始执行，未应用此次反馈，请稍后重试')
        p=current
        p['history'].append({'version':p['version'],'plan':p['plan'],'at':time.time(),'reason':'多点反馈：'+text.strip()})
        p['plan']=new;p['version']+=1
        event={'id':uuid.uuid4().hex,'source':{k:body[k] for k in ('output_id','shot_id','quality','version')},
               'text':text.strip(),'hits':hits,'version':p['version'],'at':time.time(),'scope':'选中网格的材质槽'}
        p['feedback']=(p.get('feedback',[])+[event])[-50:]
        put('project',p)
        job=engine.submit(ident,'preview','preview',[output['shot_id']],request_key='feedback:'+event['id'])
        event['job_id']=job['id'];put('project',p)
    return jsonify(engine.project_view(ident))

@app.post('/api/projects/<ident>/jobs')
def job_create(ident):
    body=request.get_json(force=True)
    return jsonify(engine.submit(ident,body.get('kind','preview'),body.get('quality','preview'),body.get('shot_ids'),request.headers.get('Idempotency-Key'))),202

@app.get('/api/jobs/<ident>')
def job_read(ident): return jsonify(get('job',ident))

@app.post('/api/jobs/<ident>/cancel')
def job_cancel(ident): return jsonify(engine.cancel(ident))

@app.post('/api/jobs/<ident>/retry')
def job_retry(ident):
    old=get('job',ident)
    if old['status'] in ['running','queued']: return jsonify(old)
    # Retry reproduces the failed task, not subsequent edited settings.
    with LOCK:
        for existing in all_records('job'):
            if existing['project_id']==old['project_id'] and existing['status'] in ['running','queued']: return jsonify(existing)
        new={**old,'id':uuid.uuid4().hex,'status':'queued','stage':'等待继续','error':None,'progress':0,'completed':[],'reused':[],'log_tail':[],'current_shot':None,'created_at':time.time(),'retry_of':ident}
        for key in ['finished_at','started_at','sample_progress','fallback_reason']: new.pop(key,None)
        put('job',new);engine.QUEUE.put(new['id'])
    return jsonify(new),202

@app.get('/files/<path:filename>')
def files(filename):
    path=(DATA/filename).resolve()
    if DATA.resolve() not in path.parents or path.suffix.lower() not in ['.png','.jpg','.blend','.c4d','.zip','.json','.fbx']: abort(404)
    return send_from_directory(DATA,filename,as_attachment=request.args.get('download')=='1')

@app.post('/api/projects/<ident>/exports')
def scene_export_create(ident):return jsonify(scene_exports.submit(ident,request.get_json(force=True))),202

@app.get('/api/exports/<ident>')
def scene_export_read(ident):return jsonify(get('export',ident))

@app.post('/api/exports/<ident>/cancel')
def scene_export_cancel(ident):return jsonify(scene_exports.stop(ident))

@app.get('/api/projects/<ident>/bundle')
def bundle(ident):
    p=get('project',ident);buf=io.BytesIO()
    quality=request.args.get('quality','all');include_blend=request.args.get('blend','1')=='1'
    with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('project.json',json.dumps(p,ensure_ascii=False,indent=2))
        seen=set()
        for o in p['outputs']:
            if quality!='all' and o['quality']!=quality: continue
            for key in ['png_url','jpg_url']+(['blend_url'] if include_blend else []):
                if not o.get(key): continue
                path=DATA/o[key][7:]
                if path.exists():
                    arc='%s/v%s/%s/%s'%(o['quality'],o['version'],o['shot_id'],path.name)
                    if arc not in seen: z.write(path,arc);seen.add(arc)
        for j in all_records('job'):
            if j['project_id']==ident: z.writestr('jobs/'+j['id']+'.json',json.dumps(j,ensure_ascii=False,indent=2))
        # Keep downloaded PBR sources and their license manifests beside packed
        # Blender scenes so the external material choices remain reproducible.
        material_root=(DATA/ident/'materials').resolve()
        for override in p['plan'].get('material_overrides',[])+p['plan'].get('object_material_overrides',[]):
            for filename in override.get('textures',{}).values():
                path=Path(filename).resolve()
                if material_root not in path.parents or not path.is_file(): continue
                for resource in [path,path.parent/'manifest.json']:
                    if not resource.is_file(): continue
                    arc='materials/'+resource.relative_to(material_root).as_posix()
                    if arc not in seen: z.write(resource,arc);seen.add(arc)
        for task in all_records('material_task'):
            if task.get('project_id')==ident:
                z.writestr('material-tasks/'+task['id']+'.json',json.dumps(task,ensure_ascii=False,indent=2))
    buf.seek(0)
    return send_file(buf,mimetype='application/zip',as_attachment=True,download_name=p['slug']+'_images.zip')

@app.get('/api/examples')
def examples():
    path=ROOT/'samples'/'index.json'
    return jsonify(json.loads(path.read_text(encoding='utf-8')) if path.exists() else [])

@app.post('/api/examples/<ident>/import')
def example_import(ident):
    listing=json.loads((ROOT/'samples'/'index.json').read_text(encoding='utf-8'))
    entry=next((x for x in listing if x['id']==ident),None)
    if not entry: abort(404)
    base=DATA/uuid.uuid4().hex/'originals';base.mkdir(parents=True)
    src=ROOT/'samples'/entry['file']
    if src.suffix.lower()=='.zip': extract_archive(src,base)
    else: shutil.copy2(src,base/src.name)
    return jsonify(create_project(base,entry['name'],{'license':entry.get('license'),'example_id':ident})),201

if __name__=='__main__':
    # A second launch must not mark a currently running renderer as interrupted.
    instance_lock=(DATA/'studio.lock').open('a+b')
    instance_lock.seek(0,2)
    if instance_lock.tell()==0: instance_lock.write(b'0');instance_lock.flush()
    instance_lock.seek(0)
    try:
        if os.name=='nt':
            import msvcrt
            msvcrt.locking(instance_lock.fileno(),msvcrt.LK_NBLCK,1)
        else:
            import fcntl
            fcntl.flock(instance_lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
    except OSError:
        raise SystemExit('物影 Studio 已在运行，请打开已有本地页面。')
    engine.start()
    scene_exports.start()
    import material_agent
    material_agent.recover_interrupted()
    port=int(os.getenv('STUDIO_PORT','8765'))
    print('物影 Studio  http://127.0.0.1:%s'%port,flush=True)
    app.run(host='127.0.0.1',port=port,debug=False,threaded=True,use_reloader=False)
