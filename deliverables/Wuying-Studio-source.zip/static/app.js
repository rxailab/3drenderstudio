'use strict';
const $ = id => document.getElementById(id);
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const clone = value => JSON.parse(JSON.stringify(value));
const presets = {matte_plastic:'哑光塑料',glossy_plastic:'亮面塑料',painted_metal:'喷涂金属',brushed_metal:'拉丝金属',polished_metal:'抛光金属',glass:'玻璃',rubber:'橡胶',fabric:'织物',leather:'皮革',wood:'木材',ceramic:'陶瓷'};
const statusNames = {analyzing:'模型分析中',ready:'可开始拍摄',failed:'需要处理',queued:'等待执行',running:'正在执行',completed:'已完成',cancelled:'已取消',interrupted:'等待继续'};
const sourceNames = {rules:'规则推导',user:'用户指定',ai:'AI 分析',model:'模型自带',fallback:'占位材质',default:'默认材质'};
let current = null, draft = null, allProjects = [], activeShot = null, selectedShots = new Set(), selectedMaterial = null, cameraShot = null;
let dirty = false, busy = false, polling = false, system = null, uploadFiles = [], toastTimer, syncSignature = '', currentOutput = null;
let serviceDisconnected = false;
let comparePrevious=false, viewerLatestKey='', styleFocusNotice='';
let inspectorTab='review', materialAgentSubmitting=false, materialAgentProjectId='', materialAgentRenderedKey='';
const inspectorScrollPositions={review:0,material:0,plan:0};
const materialAgentRecords=new Map(), materialAgentDisclosures=new Map();
let sceneExportSource = null, sceneExportSubmitting = false, sceneExportProjectId = null, sceneExportJobsSignature = '', sceneExportOptionsSignature = '';
let aiSettingsBusy = false, aiSettings = null;
let feedbackMode = false, feedbackSource = null, feedbackPoints = [], feedbackEpoch = 0;
let partEditTab = 'material', partMaterialSignature = '', partMaterialFields = new Set(), partMaterialValueFields = new Set(), realismBusy = false, reviewSeenKey = '';
const partFieldControls = {preset:['partPreset','partPresetUse'],color:['partColor','partColorUse'],roughness:['partRoughness','partRoughnessUse'],metallic:['partMetallic','partMetallicUse'],transmission:['partTransmission','partTransmissionUse']};
const editedMaterialColors = new Set();
async function api(path, options = {}) {
  if (options.body && !(options.body instanceof FormData)) { options.headers = {...options.headers,'Content-Type':'application/json'}; options.body = JSON.stringify(options.body); }
  const res = await fetch(path, options);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `请求失败 (${res.status})`);
  return data;
}
function toast(message, error = false) { clearTimeout(toastTimer); $('toast').textContent = message; $('toast').className = 'toast' + (error ? ' error' : ''); $('toast').hidden = false; toastTimer = setTimeout(() => $('toast').hidden = true, error ? 8000 : 4500); }
function activeJob() { return current?.jobs?.find(j => ['running','queued'].includes(j.status)); }
function shots() { return draft?.shots || current?.plan?.shots || []; }
function latestOutput(id) { return [...(current?.outputs || [])].filter(o => o.shot_id === id).sort((a,b) => b.version-a.version || (b.created_at || 0)-(a.created_at || 0))[0]; }
function previousOutput(latest) {
  if(!latest)return null;
  // A new engine can re-render the same plan version. Compare with the exact
  // real snapshot recorded by that job, not an unrelated earlier version.
  const job=(current?.jobs || []).find(j=>j.id===latest.job_id);
  const ref=job?.automatic_previous_preview;
  if(ref && ref.shot_id===latest.shot_id && ref.png_url && ref.png_url!==latest.png_url){
    const exact=(current?.outputs || []).find(o=>o.job_id===ref.job_id && o.shot_id===ref.shot_id && o.version===ref.version && o.png_url===ref.png_url);
    if(exact)return exact;
  }
  return [...(current?.outputs || [])].filter(o=>o.shot_id===latest.shot_id && o.version<latest.version && o.png_url && o.png_url!==latest.png_url)
    .sort((a,b)=>b.version-a.version || Number(b.quality===latest.quality)-Number(a.quality===latest.quality) || (b.created_at || 0)-(a.created_at || 0))[0] || null;
}
function focusStyleShot(style,previousStyle) {
  if(style===previousStyle)return false;
  if(activeShot!=='hero'){styleFocusNotice='棚拍风格已改为'+({dark:'深色',soft:'浅色柔光',white:'白底'}[style] || style)+'，以新预览为准。';return false;}
  const target=shots().find(s=>s.id==='campaign' && !s.style) || shots().find(s=>s.id!=='hero' && !s.style);
  if(!target)return false;
  stashCamera();activeShot=target.id;cameraShot=target.id;selectedShots.add(target.id);comparePrevious=false;
  $('cameraShot').value=cameraShot;syncCamera();
  styleFocusNotice='白底主图保持白底；已切换到'+({dark:'深色',soft:'浅色柔光',white:'白底'}[style] || '')+'棚拍镜头。';
  if(typeof localStorage!=='undefined')localStorage.setItem('wuying-shot-'+current.id,activeShot);
  return true;
}
function outputNotice(output,latest) {
  if(comparePrevious && output)return output.version===latest.version?`正在查看优化前的真实预览（方案 v${output.version}）；返回最新可查看本轮结果。`:`正在对比上一版 v${output.version}；返回最新可查看 v${latest.version}。`;
  const running=activeJob();
  if(!running && automaticMaterialBusy())return '正在自动寻找或应用材质；当前真实图片保留，新预览完成后自动更新。';
  if(running?.shot_ids?.includes(activeShot))return `正在生成${sceneShotLabel(activeShot)}的新结果${output?'；暂时显示 v'+output.version+'，完成后自动更新。':'，完成后自动显示。'}`;
  if(dirty)return (styleFocusNotice?styleFocusNotice+' ':'')+'方案尚未渲染，生成预览后查看变化。';
  if(output && output.version!==current?.version)return (styleFocusNotice?styleFocusNotice+' ':'')+`当前显示旧图 v${output.version}，方案 v${current.version} 尚未生成这个镜头。`;
  const reviewNotice=(current?.jobs || []).find(job=>job.id===output?.job_id)?.review_notice || '';
  if(reviewNotice){
    const attempts=output?.corrections || [],chosen=attempts.find(a=>a.applied);
    return (attempts.length>1?(chosen?.round?`已显示本轮第 ${chosen.round} 轮的真实结果。`:'本轮候选未优于本轮初始预览，已保留本轮初始结果。')+' ':'')+reviewNotice;
  }
  if(styleFocusNotice && activeShot!=='hero')return styleFocusNotice;
  const attempts=output?.corrections || [];
  if(attempts.length>1){const chosen=attempts.find(a=>a.applied);return chosen?.round?`已显示自动修正第 ${chosen.round} 轮的真实结果，可对比上一版。`:'自动候选未优于本轮初始预览，已保留本轮初始结果；可在诊断记录中查看比较。';}
  if(activeShot==='hero' && current?.plan?.style!=='white')return '白底主图始终保持白底；棚拍风格的变化请查看「棚拍宣传」。';
  return output?.version>1?'已显示最新实际渲染，可对比上一版查看变化。':'';
}
function filenameSize(bytes) { return bytes > 1024*1024 ? (bytes/1024/1024).toFixed(1)+' MB' : Math.ceil(bytes/1024)+' KB'; }
function markDirty() { dirty = true; $('savePlan').disabled = false; $('savePlan').textContent = '保存方案'; $('dirtyNote').hidden = false; }
function options(select, values, selected) { select.innerHTML = values.map(x => `<option value="${esc(x.value)}">${esc(x.label)}</option>`).join(''); if (values.some(x => x.value === selected)) select.value = selected; }
function setValue(id,value) { $(id).value = value ?? ''; }
function readNumber(id) { return Number($(id).value); }
function colorHex(color) { if (typeof color === 'string') return color; if (!Array.isArray(color)) return '#8c9aab'; return '#'+color.slice(0,3).map(c => Math.round(Math.min(1,Math.max(0,c <= .0031308 ? c*12.92 : 1.055*Math.pow(c,1/2.4)-.055))*255).toString(16).padStart(2,'0')).join(''); }
function describeSource(value) { return sourceNames[value] || value || '未记录'; }
function updateRangeLabels() { $('marginValue').textContent = $('margin').value+'%'; $('softnessValue').textContent = Number($('softness').value).toFixed(2); $('exposureValue').textContent = $('exposure').value+' EV'; $('roughnessValue').textContent = Number($('roughness').value).toFixed(2); const aspect = document.querySelector('[name=aspect]:checked')?.value || '1:1'; $('outputSize').textContent = '成品 '+({'1:1':'4096 × 4096','4:3':'4096 × 3072','3:4':'3072 × 4096'}[aspect])+' px'; }
function syncMaterial() {
  const mat = (current.analysis?.materials || []).find(m => m.name === selectedMaterial) || {};
  const override = (draft.material_overrides || []).find(m => m.name === selectedMaterial);
  setValue('materialPreset',override?.preset || ''); setValue('materialColor',colorHex(override?.color || mat.color));
  setValue('roughness',override?.roughness ?? mat.roughness ?? .45); setValue('metallic',override?.metallic ?? mat.metallic ?? 0); setValue('transmission',override?.transmission ?? mat.transmission ?? 0);
  $('materialEditing').hidden = !override;
  $('materialSource').textContent = override ? '当前：'+describeSource(override.source || 'user')+(override.license ? '；许可 '+override.license : '') : `${describeSource(mat.source)} · 材质记录置信度 ${Math.round((mat.confidence || 0)*100)}%${mat.suggested_preset ? '；建议 '+(presets[mat.suggested_preset] || mat.suggested_preset)+'（规则推测 '+Math.round((mat.suggestion_confidence || 0)*100)+'%）' : ''}`;
  updateRangeLabels();
}
function stashMaterial() {
  if (!draft || !selectedMaterial) return;
  const prior = (draft.material_overrides || []).find(m => m.name === selectedMaterial) || {};
  draft.material_overrides = (draft.material_overrides || []).filter(m => m.name !== selectedMaterial);
  if ($('materialPreset').value) {
    const override = {...prior,name:selectedMaterial,preset:$('materialPreset').value,roughness:readNumber('roughness'),metallic:readNumber('metallic'),transmission:readNumber('transmission'),source:'user'};
    // An untouched color swatch is a display value, not authorization to disconnect
    // the asset's linked base-color texture (which may contain product branding).
    if (editedMaterialColors.has(selectedMaterial)) override.color = $('materialColor').value;
    draft.material_overrides.push(override);
  }
}
function syncCamera() {
  const s = shots().find(s => s.id === cameraShot); if (!s) return;
  setValue('azimuth',s.azimuth);setValue('elevation',s.elevation);setValue('focalLength',s.focal_length);setValue('detailTarget',s.target_object || '');
  $('detailTarget').disabled = s.kind !== 'detail';
}
function stashCamera() { const s = shots().find(s => s.id === cameraShot); if (!s) return; Object.assign(s,{azimuth:readNumber('azimuth'),elevation:readNumber('elevation'),focal_length:readNumber('focalLength')});if ($('detailTarget').value) s.target_object = $('detailTarget').value;else delete s.target_object; }
function syncSettings() {
  if (!current) return;
  draft = clone(current.plan);dirty = false;editedMaterialColors.clear();
  document.querySelectorAll('[name=style]').forEach(el => el.checked = el.value === draft.style);document.querySelectorAll('[name=aspect]').forEach(el => el.checked = el.value === draft.aspect);
  setValue('margin',draft.margin*100);setValue('softness',draft.light_softness);setValue('exposure',draft.exposure);setValue('textureScale',draft.texture_scale);setValue('textureRotation',draft.texture_rotation);
  ['rotateX','rotateY','rotateZ'].forEach((id,i) => setValue(id,draft.rotation[i]));$('repairNormals').checked = !!draft.repair.normals;$('repairSmooth').checked = !!draft.repair.smooth;
  setValue('timeBudget',draft.time_budget);setValue('maxCorrections',draft.max_corrections);$('visualReview').checked=draft.visual_review!==false;
  const materials = current.analysis?.materials || [];
  if (!materials.some(m => m.name === selectedMaterial)) selectedMaterial = materials[0]?.name || null;
  options($('materialSlot'),materials.map(m => ({value:m.name,label:m.name})),selectedMaterial);
  if (!shots().some(s => s.id === cameraShot)) cameraShot = activeShot || shots()[0]?.id;
  options($('cameraShot'),shots().map(s => ({value:s.id,label:s.label})),cameraShot);
  const obs = (current.analysis?.objects || []).map(o => ({value:o.name,label:o.name+(o.parent ? ' ↳ '+o.parent : '')}));
  options($('detailTarget'),[{value:'',label:'自动选择目标'},...obs], '');options($('poseObject'),[{value:'',label:'保留静态姿态'},...obs],draft.pose?.object || '');
  ['poseX','poseY','poseZ'].forEach((id,i) => setValue(id,draft.pose?.rotation?.[i] || 0));['moveX','moveY','moveZ'].forEach((id,i) => setValue(id,draft.pose?.translation?.[i] || 0));setValue('animationFrame',draft.pose?.frame);
  $('animationInfo').textContent = current.analysis?.animations?.length ? '模型已有动画：'+current.analysis.animations.map(a => `${a.name} (${a.frame_range.join('–')})`).join('，') : '未检测到已有动画。部件运动需要手动确认。';
  syncMaterial();syncCamera();updateRangeLabels();$('savePlan').textContent = '方案已保存';$('savePlan').disabled = true;$('dirtyNote').hidden = true;
  syncSignature = `${current.id}:${current.version}:${!!current.analysis}`;
}
function gatherPlan() {
  stashMaterial();stashCamera();
  draft.visual_review=$('visualReview').checked;
  Object.assign(draft,{style:document.querySelector('[name=style]:checked').value,aspect:document.querySelector('[name=aspect]:checked').value,margin:readNumber('margin')/100,light_softness:readNumber('softness'),exposure:readNumber('exposure'),texture_scale:readNumber('textureScale'),texture_rotation:readNumber('textureRotation'),rotation:['rotateX','rotateY','rotateZ'].map(readNumber),repair:{normals:$('repairNormals').checked,smooth:$('repairSmooth').checked},time_budget:readNumber('timeBudget'),max_corrections:readNumber('maxCorrections')});
  draft.pose = {};
  if ($('poseObject').value) draft.pose = {object:$('poseObject').value,rotation:['poseX','poseY','poseZ'].map(readNumber),translation:['moveX','moveY','moveZ'].map(readNumber)};
  if ($('animationFrame').value !== '') draft.pose.frame = readNumber('animationFrame');
  return draft;
}
async function savePlan(silent = false) {
  if (!current || !dirty) return;
  const id = current.id;
  const result = await api(`/api/projects/${id}/plan`,{method:'POST',body:gatherPlan()});
  if (current?.id !== id) return;
  current = result;syncSettings();renderProject();if (!silent) toast('摄影方案已保存，重新预览即可查看变化。');
}
function renderLibrary() {
  $('projectCount').textContent = allProjects.length;
  options($('mobileProjectSelect'),[{value:'',label:allProjects.length?'选择摄影项目':'尚无摄影项目'},...allProjects.map(p=>({value:p.id,label:p.name}))],current?.id || '');
  $('projectList').innerHTML = allProjects.length ? allProjects.map(p => {const out=p.outputs?.at(-1);return `<button class="project-item ${p.id===current?.id?'active':''}" data-project="${esc(p.id)}"><div class="project-thumb">${out ? `<img src="${esc(out.jpg_url || out.png_url)}" alt="" loading="lazy">` : '◇'}</div><div><strong>${esc(p.name)}</strong><small>${esc(statusNames[p.status] || p.status)}${p.outputs?.length ? ' · '+p.outputs.length+' 张' : ''}</small></div></button>`;}).join('') : '<p class="muted">还没有摄影项目。<br>上传一个模型开始吧。</p>';
}
function renderViewer() {
  const shot = shots().find(s => s.id === activeShot) || shots()[0];if (!shot) return;activeShot = shot.id;
  const latest=latestOutput(activeShot),latestKey=latest?current.id+':'+sceneOutputKey(latest):current.id+':'+activeShot;
  if(viewerLatestKey!==latestKey){comparePrevious=false;viewerLatestKey=latestKey;}
  const previous=previousOutput(latest);
  currentOutput = comparePrevious && previous?previous:latest;$('shotTitle').textContent = shot.label;
  $('comparePreview').hidden=!previous;$('comparePreview').setAttribute('aria-pressed',comparePrevious);
  const sameVersion=previous && previous.version===latest.version;
  $('comparePreview').textContent=comparePrevious?'返回最新 v'+latest.version:sameVersion?'对比优化前':'对比上一版 v'+(previous?.version || '');
  $('previewNotice').textContent=outputNotice(currentOutput,latest);$('previewNotice').hidden=!$('previewNotice').textContent;
  if (currentOutput) {
    const o=currentOutput;if ($('renderImage').getAttribute('src') !== o.png_url) $('renderImage').src=o.png_url;
    $('renderImage').hidden=false;$('renderEmpty').hidden=true;$('imageStamp').hidden=false;$('imageStamp').textContent=`${comparePrevious?(sameVersion?'优化前 · ':'对比上一版 · '):'真实 Cycles 渲染 · '}v${o.version}`;
    const old=o.version!==current.version;$('renderKind').textContent=(o.quality==='preview'?'快速预览':'4K 成品')+(old?' · 旧版':'');
    $('imageMeta').textContent=`${o.width} × ${o.height} px · ${o.quality==='preview'?'预览尺寸':'原生渲染'}${old?' · 当前方案已修改，请重新预览':''}`;
    $('imageDownloads').hidden=false;for (const [id,key] of [['downloadPng','png_url'],['downloadJpg','jpg_url'],['downloadBlend','blend_url']]) {$(id).hidden=!o[key];if(o[key])$(id).href=o[key]+'?download=1';}
    $('sceneExportButton').disabled=false;
  } else {
    $('renderImage').hidden=true;$('renderEmpty').hidden=false;$('imageStamp').hidden=true;$('imageDownloads').hidden=true;
    $('renderKind').textContent='等待预览';$('imageMeta').textContent='预览与成品使用同一套摄影方案';
    const analyzing=!current.analysis;$('renderEmpty').querySelector('h2').textContent=analyzing?'正在读取模型':'摄影棚已准备好';$('renderEmpty').querySelector('p').textContent=analyzing?'模型检查完成后即可生成真实预览。':'选择右侧风格，生成第一张真实预览。';
    $('emptyPreview').disabled=analyzing || !!activeJob() || busy;
  }
  renderFeedback();renderReview();
}
function sceneOutputKey(output) {
  return JSON.stringify([output.job_id || '',output.shot_id,output.version,output.quality,output.created_at || '',output.blend_url || '']);
}
function sceneQualityLabel(quality) { return {preview:'快速预览',fine:'精细 4K',standard:'标准 4K'}[quality] || '场景快照'; }
function sceneShotLabel(id) { return current?.plan?.shots?.find(shot=>shot.id===id)?.label || id || '镜头'; }
function sceneOutputLabel(output) {
  const stamp = output.created_at ? new Date(typeof output.created_at==='number'?output.created_at*1000:output.created_at) : null;
  const date = stamp && !Number.isNaN(stamp.getTime()) ? ' · '+stamp.toLocaleString('zh-CN',{month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit',second:'2-digit'}) : '';
  return `${sceneShotLabel(output.shot_id)} · v${output.version} · ${sceneQualityLabel(output.quality)}${date}`;
}
function renderSceneExportControls() {
  const format = document.querySelector('[name=sceneExportFormat]:checked')?.value || 'blend';
  const capability = system?.scene_exports;
  const source = sceneExportSource;
  const c4d = format==='c4d';
  $('sceneExportContext').textContent = source ? `已选：${sceneShotLabel(source.shot_id)} · 方案 v${source.version} · ${sceneQualityLabel(source.quality)}。${source.version!==current?.version || dirty?'当前方案有后续调整，导出的仍是所选图片对应的场景。':'相机、灯光与材质取自这张图片的场景快照。'}` : '请先生成一张预览或成品，再导出对应场景。';
  $('sceneExportC4dNote').hidden=!c4d;
  let capabilityMessage;
  if (c4d) {
    const statusMessage = {ready:'本机 Cinema 4D 转换已验证。',unverified:'已找到 Cinema 4D；启动与许可证尚未验证，将在导出时检查。',unavailable:'本机 Cinema 4D 转换不可用；仍可尝试生成手动转换包。',license_required:'Cinema 4D 许可证尚未就绪；仍可尝试生成手动转换包。'};
    capabilityMessage = capability ? (statusMessage[capability.c4d_status] || 'Cinema 4D 转换能力尚未验证。') : 'Cinema 4D 转换能力尚未读取，将在导出时由本机服务检查。';
    if (capability?.c4d_message) capabilityMessage+=' '+capability.c4d_message;
  } else capabilityMessage = capability?.blender_available===false ? '本机 Blender 不可用，请检查运行环境；服务将检查已有场景能否打包。' : capability?.blender_available ? '本机 Blender 可用，可打包原生场景与贴图。' : '导出时将检查所选 Blender 场景与贴图。';
  $('sceneExportCapability').textContent=capabilityMessage;
  $('sceneExportCapability').classList.toggle('needs-review',c4d && capability?.c4d_status!=='ready');
  $('sceneExportSubmit').disabled=sceneExportSubmitting || !source || current?.id!==sceneExportProjectId;
  $('sceneExportSource').disabled=sceneExportSubmitting || !source;
  document.querySelectorAll('[name=sceneExportFormat]').forEach(input=>input.disabled=sceneExportSubmitting);
  $('sceneExportSubmit').textContent=sceneExportSubmitting?'正在提交…':!c4d?'生成 Blender 工程包':['unavailable','license_required'].includes(capability?.c4d_status)?'尝试转换 / 生成转换包':'生成 C4D 工程包';
}
function renderSceneExports() {
  if (!$('sceneExportDialog').open || !current || sceneExportProjectId!==current.id) return;
  const outputs=[...(current.outputs || [])].sort((a,b)=>b.version-a.version || (b.created_at || 0)-(a.created_at || 0));
  const signature=JSON.stringify(outputs.map(output=>[sceneOutputKey(output),sceneOutputLabel(output)]));
  if (signature!==sceneExportOptionsSignature) {
    const selected=sceneExportSource ? sceneOutputKey(sceneExportSource) : '';
    options($('sceneExportSource'),outputs.map(output=>({value:sceneOutputKey(output),label:sceneOutputLabel(output)})),selected);
    // Keep the chosen snapshot stable when a new render arrives during export.
    if (!outputs.some(output=>sceneOutputKey(output)===selected)) sceneExportSource=outputs[0]?clone(outputs[0]):null;
    sceneExportOptionsSignature=signature;
  }
  renderSceneExportControls();
  const records=[...(current.exports || [])].sort((a,b)=>(b.created_at || 0)-(a.created_at || 0));
  const jobsSignature=JSON.stringify(records);
  if (jobsSignature===sceneExportJobsSignature) return;
  sceneExportJobsSignature=jobsSignature;
  const statuses={queued:'等待导出',running:'正在导出',completed:'工程已完成',failed:'导出失败',interrupted:'导出已中断',cancelled:'导出已取消'};
  $('sceneExportJobs').innerHTML=records.length?records.map(record=>{
    const running=['queued','running'].includes(record.status),completed=record.status==='completed';
    const format=record.format==='c4d'?'Cinema 4D':'Blender';
    const warnings=Array.isArray(record.warnings)?record.warnings:record.warnings?[record.warnings]:[];
    return `<article class="scene-export-job ${running?'is-running':''} ${['failed','interrupted'].includes(record.status)?'is-failed':''}"><div class="scene-export-job-heading"><strong>${format} <span>.${esc(record.format)}</span></strong><span class="pill">${esc(statuses[record.status] || record.status)}</span></div><p class="scene-export-job-context">${esc(sceneOutputLabel(record))}</p>${record.stage?`<p class="scene-export-stage">${running?'<span class="scene-export-activity" aria-hidden="true"></span>':''}${esc(record.stage)}</p>`:''}${record.error?`<p class="job-error">${esc(record.error)}</p>`:''}${warnings.length?`<ul class="scene-export-warnings">${warnings.map(warning=>`<li>${esc(typeof warning==='string'?warning:JSON.stringify(warning))}</li>`).join('')}</ul>`:''}<div class="scene-export-links">${completed && record.download_url?`<a class="button secondary" href="${esc(record.download_url)}" download>下载 ${format} 工程 ZIP</a>`:''}${completed && record.native_url?`<a href="${esc(record.native_url)}" download>单独下载 .${esc(record.format)}</a>`:''}${record.package_url && (!completed || record.package_url!==record.download_url)?`<a class="button secondary" href="${esc(record.package_url)}" download>下载手动转换包（非 .c4d 工程）</a>`:''}</div></article>`;
  }).join(''):'<p class="scene-export-empty">还没有导出记录。选择格式后即可生成工程包。</p>';
  $('sceneExportAnnouncement').textContent=records.length?`${records.length} 条导出记录。最近一次 ${records[0].format==='c4d'?'Cinema 4D':'Blender'}：${statuses[records[0].status] || records[0].status}。${records[0].stage || ''}`:'还没有导出记录。';
}
async function showSceneExport() {
  if (!currentOutput || !current) return toast('生成预览后即可导出对应场景。',true);
  sceneExportProjectId=current.id;sceneExportSource=clone(currentOutput);sceneExportOptionsSignature='';sceneExportJobsSignature='';
  $('sceneExportError').textContent='';$('sceneExportDialog').showModal();renderSceneExports();
  try {system=await api('/api/system');if($('sceneExportDialog').open)renderSceneExportControls();} catch(error) {$('sceneExportCapability').textContent='暂时无法读取运行环境。提交后以实际导出结果为准。';}
}
async function submitSceneExport(event) {
  event.preventDefault();
  if(sceneExportSubmitting || !sceneExportSource || current?.id!==sceneExportProjectId)return;
  const projectId=sceneExportProjectId,source=clone(sceneExportSource),format=document.querySelector('[name=sceneExportFormat]:checked').value;
  sceneExportSubmitting=true;$('sceneExportError').textContent='';renderSceneExportControls();
  try {
    const record=await api(`/api/projects/${projectId}/exports`,{method:'POST',body:{format,output_id:source.job_id,shot_id:source.shot_id,quality:source.quality,version:source.version}});
    if(current?.id===projectId){current.exports=[...(current.exports || []).filter(item=>item.id!==record.id),record];renderSceneExports();}
    toast('已提交场景导出，可在导出记录中查看进度。');
  } catch(error) {if(sceneExportProjectId===projectId)$('sceneExportError').textContent=error.message;}
  finally {sceneExportSubmitting=false;if($('sceneExportDialog').open)renderSceneExportControls();}
}
function aiStatusLabel(settings=system?.ai) {
  if (!settings) return system?.ai_mode==='ai'?'AI 已配置 · 尚未验证':'内置规则模式';
  const labels={missing_key:'待填写 API Key',disabled:'AI 已关闭 · 内置规则',configured:'AI 已配置 · 尚未验证',verified:'AI 连接已验证',error:'AI 连接需要处理'};
  return labels[settings.status] || settings.message || 'AI 尚未验证';
}
function visionState() {
  const settings=system?.ai?.vision_config || system?.ai;
  if(!settings)return {status:system?.ai_mode==='ai'?'configured':'missing',model:'',attemptable:system?.ai_mode==='ai'};
  const attemptable=!!(settings.enabled && settings.key_configured && settings.model);
  const status=!settings.enabled?'disabled':!settings.key_configured?'missing_key':!settings.model?'missing_model':settings.status || 'configured';
  return {status,model:settings.model || '',attemptable};
}
function visionStatusLabel() {
  const v=visionState(),labels={verified:'已验证',configured:'已配置，尚未验证',error:'最近调用失败',missing:'未配置',missing_key:'缺少 Key',missing_model:'未填写模型',disabled:'已关闭'};
  return '视觉配置：'+(v.model?v.model+' · ':'')+(labels[v.status] || '状态待确认');
}
function updateVisionStatus() {
  const review=currentOutput?.review;
  const used=review?.source==='ai' && review.model?'；本图诊断：'+review.model:review?.source==='rules'?'；本图诊断：基础规则':'';
  $('visionModelStatus').textContent=visionStatusLabel()+used;
}
function updateAiMode() {
  const settings=system?.ai;
  $('instructionMode').textContent='文字 '+aiStatusLabel(settings)+(settings?.enabled && settings?.key_configured && settings?.model?' · '+settings.model:'');
  updateVisionStatus();
  $('aiSettingsButton').title=aiStatusLabel(settings);
}
function applyAiPublic(settings) {
  aiSettings=settings;system=system || {};system.ai=settings;
  system.ai_mode=settings.enabled && settings.key_configured && settings.model?'ai':'rules';
  updateAiMode();renderFeedback();if(current){renderReview();renderMaterialAgent();}
}
function renderAiConnection(settings) {
  $('aiConnectionStatus').textContent=aiStatusLabel(settings)+(settings?.message?'：'+settings.message:'');
  $('aiConnectionStatus').classList.toggle('is-error',settings?.status==='error');
  $('aiConnectionStatus').classList.toggle('is-verified',settings?.status==='verified');
  $('aiKeyHint').textContent=settings?.key_configured?'本机已保存 Key。留空将保留，填写新 Key 将替换。':'尚未保存 Key。请填写 HAI 平台的 Access Token。';
  $('aiApiKey').placeholder=settings?.key_configured?'留空保留已保存的 Key':'填写 HAI Access Token';
  const vision=settings?.vision_config;
  $('visionConnectionStatus').textContent=vision ? (aiStatusLabel(vision)+(vision.message?'：'+vision.message:'')) : '未设置独立视觉模型，使用上面的 AI 模型。';
  $('visionConnectionStatus').classList.toggle('is-error',vision?.status==='error');
  $('visionConnectionStatus').classList.toggle('is-verified',vision?.status==='verified');
}
function renderVisionFields(){const enabled=$('visionEnabled').checked;$('visionFields').hidden=!enabled;for(const id of ['visionProvider','visionBaseUrl','visionModel','visionApiKey','visionClearKey','visionSaveTest'])$(id).disabled=aiSettingsBusy || !enabled;}
async function showAiSettings() {
  $('aiSettingsError').textContent='';$('aiApiKey').value='';$('aiClearKey').checked=false;$('visionApiKey').value='';$('visionClearKey').checked=false;
  try {
    const settings=await api('/api/ai/settings');applyAiPublic(settings);
    setValue('aiProvider',settings.provider || 'anthropic');setValue('aiBaseUrl',settings.base_url || 'https://api.hai.network/anthropic');setValue('aiModel',settings.model || 'claude-sonnet-4-6');$('aiEnabled').checked=settings.enabled!==false;
    const vision=settings.vision_config || {}; $('visionEnabled').checked=vision.enabled===true && !vision.inherits;
    setValue('visionProvider',vision.inherits?'openai':vision.provider || 'openai');setValue('visionBaseUrl',vision.inherits?'https://api.hai.network/openai':vision.base_url || 'https://api.hai.network/openai');setValue('visionModel',vision.inherits?'gpt-5.5-2026-04-23':vision.model || 'gpt-5.5-2026-04-23');renderVisionFields();
    renderAiConnection(settings);if(!$('aiSettingsDialog').open)$('aiSettingsDialog').showModal();
  } catch(error){toast('无法读取 AI 设置：'+error.message,true);}
}
function setAiSettingsBusy(value) {
  aiSettingsBusy=value;
  for(const id of ['aiSave','aiSaveTest','aiProvider','aiBaseUrl','aiModel','aiApiKey','aiEnabled','aiClearKey','visionEnabled'])$(id).disabled=value;
  renderVisionFields();
  $('aiSaveTest').textContent=value?'正在处理…':'保存并测试连接';
}
async function saveAiSettings(test=false) {
  if(aiSettingsBusy || !$('aiSettingsForm').reportValidity())return;
  const body={provider:$('aiProvider').value,base_url:$('aiBaseUrl').value.trim(),model:$('aiModel').value.trim(),enabled:$('aiEnabled').checked};
  if($('visionEnabled').checked){body.vision_enabled=true;body.vision_provider=$('visionProvider').value;body.vision_base_url=$('visionBaseUrl').value.trim();body.vision_model=$('visionModel').value.trim();if(!body.vision_base_url || !body.vision_model){$('aiSettingsError').textContent='请填写视觉服务地址和模型名称。';return;}if($('visionClearKey').checked)body.vision_clear_key=true;else if($('visionApiKey').value.trim())body.vision_api_key=$('visionApiKey').value.trim();}
  else if(aiSettings?.vision_config && !aiSettings.vision_config.inherits){body.vision_provider='';body.vision_base_url='';body.vision_model='';body.vision_enabled='';}
  if($('aiClearKey').checked)body.clear_key=true;
  else if($('aiApiKey').value.trim())body.api_key=$('aiApiKey').value.trim();
  setAiSettingsBusy(true);$('aiSettingsError').textContent='';
  try {
    const settings=await api('/api/ai/settings',{method:'PUT',body});
    $('aiApiKey').value='';$('aiClearKey').checked=false;$('visionApiKey').value='';$('visionClearKey').checked=false;delete body.api_key;delete body.vision_api_key;applyAiPublic(settings);renderAiConnection(settings);
    if(test){
      const visionTest=test==='vision';
      $(visionTest?'visionConnectionStatus':'aiConnectionStatus').textContent=visionTest?'正在使用最近的真实预览测试图像分析…':'正在向已保存的服务地址发起真实连接测试…';
      const result=await api(visionTest?'/api/ai/vision/test':'/api/ai/test',{method:'POST',body:{}});
      if(result.settings){applyAiPublic(result.settings);renderAiConnection(result.settings);}
      if(!result.success)$('aiSettingsError').textContent=result.message || '连接测试未通过。';
      else toast(result.message || 'AI 服务连接测试通过。');
    }else toast('AI 设置已保存。连接可用性需通过测试确认。');
  }catch(error){
    $('aiSettingsError').textContent=error.message;
    try{const settings=await api('/api/ai/settings');applyAiPublic(settings);renderAiConnection(settings);}catch(_){}
  }finally{delete body.api_key;delete body.vision_api_key;setAiSettingsBusy(false);}
}
function feedbackSnapshot(output=currentOutput) {
  return output?{output_id:output.job_id,shot_id:output.shot_id,quality:output.quality,version:output.version}:null;
}
function clearFeedback(close=false) {
  feedbackEpoch++;feedbackPoints=[];feedbackSource=null;if(close)feedbackMode=false;
  resetPartMaterialDraft();
  $('feedbackText').value='';$('feedbackError').textContent='';renderFeedback();
}
function imageContentRect(image=$('renderImage')) {
  const box=image.getBoundingClientRect();
  if(image.hidden || !image.naturalWidth || !image.naturalHeight || !box.width || !box.height)return null;
  const scale=Math.min(box.width/image.naturalWidth,box.height/image.naturalHeight);
  const width=image.naturalWidth*scale,height=image.naturalHeight*scale;
  return {left:box.left+(box.width-width)/2,top:box.top+(box.height-height)/2,width,height};
}
function pointFromClient(clientX,clientY,rect=imageContentRect()) {
  if(!rect || clientX<rect.left || clientX>rect.left+rect.width || clientY<rect.top || clientY>rect.top+rect.height)return null;
  return {x:(clientX-rect.left)/rect.width,y:(clientY-rect.top)/rect.height};
}
function renderFeedbackMarkers() {
  const rect=imageContentRect(),viewer=$('viewer').getBoundingClientRect();
  $('feedbackMarkers').innerHTML=feedbackMode && rect?feedbackPoints.map((point,index)=>`<button type="button" class="feedback-marker ${point.pending?'pending':point.hit?'':'miss'}" data-remove-point="${esc(point.id)}" style="left:${rect.left-viewer.left+rect.width*point.x}px;top:${rect.top-viewer.top+rect.height*point.y}px" aria-label="移除位置 ${index+1}" title="移除位置 ${index+1}">${index+1}</button>`).join(''):'';
}
function renderFeedback() {
  const canSelect=!!currentOutput && !!current?.analysis && !comparePrevious;
  if(feedbackSource && (feedbackSource.projectId!==current?.id || feedbackSource.key!==sceneOutputKey(currentOutput || {}))){
    feedbackEpoch++;feedbackPoints=[];feedbackSource=null;feedbackMode=false;resetPartMaterialDraft();$('feedbackText').value='';$('feedbackError').textContent='';
  }
  $('feedbackToggle').disabled=!canSelect || busy || !!activeJob();
  $('feedbackToggle').setAttribute('aria-pressed',feedbackMode);
  $('feedbackToggle').textContent=feedbackMode?'结束点选':'选择部件 / 材质';
  $('feedbackPanel').hidden=!feedbackMode;$('viewer').classList.toggle('feedback-selecting',feedbackMode);
  $('feedbackContext').textContent=currentOutput?`${sceneShotLabel(currentOutput.shot_id)} · 方案 v${currentOutput.version} · ${feedbackPoints.length}/12 个位置`:'';
  $('feedbackSelection').innerHTML=feedbackPoints.length?feedbackPoints.map((point,index)=>`<li><span class="feedback-number">${index+1}</span><span>${point.pending?'正在定位实际部件…':point.error?esc(point.error):point.hit?`<strong>${esc(point.object_name || '部件')}</strong><small>材质：${esc(point.material_name || '未分配材质')}</small>`:esc(point.message || '没有命中产品，请移除后重新点选')}<small>位置 ${Math.round(point.x*100)}%, ${Math.round(point.y*100)}%</small></span><button type="button" class="text-button" data-remove-point="${esc(point.id)}" aria-label="移除位置 ${index+1}">移除</button></li>`).join(''):'<li class="feedback-empty">尚未选择位置。点击产品表面添加第一个位置。</li>';
  const stale=comparePrevious || (currentOutput && currentOutput.version!==current?.version);
  const waiting=feedbackPoints.some(point=>point.pending),invalid=feedbackPoints.some(point=>!point.hit);
  let note='修改会应用到选中的部件或材质槽，并重新渲染当前镜头；不是直接涂改图片。';
  if(dirty)note='右侧有未保存的调整，请先保存方案并重新预览，再对新图片点选反馈。';
  else if(stale)note='这张图片属于旧方案，请先生成当前版本预览，再点选修改。';
  else if(system?.ai_mode!=='ai')note='局部自然语言修改需要 AI 服务。请先在 AI 设置中填写 Key 并测试连接。';
  else if(waiting)note='正在根据实际场景定位选择位置，请稍候。';
  else if(invalid)note='有位置未命中产品或定位失败，请移除后重新点选。';
  $('feedbackState').textContent=note;
  $('feedbackSubmit').disabled=busy || !!activeJob() || dirty || stale || waiting || invalid || !feedbackPoints.length || system?.ai_mode!=='ai';
  $('feedbackSubmit').textContent=busy?'正在处理…':'应用修改并重新预览';
  $('feedbackClear').disabled=!feedbackPoints.length || busy;
  $('feedbackAddPoint').disabled=!canSelect || busy || !!activeJob();
  renderPartMaterial();renderFeedbackMarkers();renderMaterialAgent();
}
function resetPartMaterialDraft() {
  partMaterialSignature='';partMaterialFields.clear();partMaterialValueFields.clear();
  for(const [,use] of Object.values(partFieldControls))$(use).checked=false;
  $('partMaterialError').textContent='';
}
function uniqueMaterialSelections() {
  const seen=new Set();
  return feedbackPoints.filter(point=>{
    if(!point.hit || point.pending)return false;
    const pair=JSON.stringify([point.object_name,point.material_name]);
    if(seen.has(pair))return false;seen.add(pair);return true;
  });
}
function commonMaterialValue(materials,field) {
  if(!materials.length || materials.some(material=>material?.[field]===undefined || material?.[field]===null))return {value:null,label:'未提供可读值'};
  const value=materials[0][field],same=materials.every(material=>typeof value==='number'?Math.abs(material[field]-value)<.00001:material[field]===value);
  return same?{value,label:typeof value==='number'?Number(value.toFixed(3)).toString():String(value)}:{value:null,label:'混合值'};
}
function partSelectionBlocked() {
  return comparePrevious || busy || !!activeJob() || automaticMaterialBusy() || dirty || !currentOutput || currentOutput.version!==current?.version || !feedbackPoints.length || feedbackPoints.some(point=>point.pending || !point.hit || !point.material_name);
}
function renderPartMaterial() {
  $('partMaterialTab').setAttribute('aria-selected',partEditTab==='material');$('partLanguageTab').setAttribute('aria-selected',partEditTab==='language');
  $('partMaterialPanel').hidden=partEditTab!=='material';$('partLanguagePanel').hidden=partEditTab!=='language';
  const selected=uniqueMaterialSelections(),materials=selected.map(point=>point.material_info || {});
  const signature=JSON.stringify(feedbackPoints.map(point=>[point.id,point.pending,point.hit,point.material_info]));
  if(signature!==partMaterialSignature){
    partMaterialSignature=signature;partMaterialFields.clear();partMaterialValueFields.clear();
    for(const [field,[id,use]] of Object.entries(partFieldControls)){
      $(use).checked=false;const common=commonMaterialValue(materials,field);
      $(id).value=field==='preset'?'':field==='color'?(common.value || '#808080'):(common.value ?? '');
    }
  }
  $('partMaterialInfo').textContent=!selected.length?'点击预览中的部件，即可查看实际渲染材质。':`已选 ${selected.length} 个网格 / 材质槽 · 来自已保存的渲染场景`;
  for(const [field,labelId] of [['color','partColorValue'],['roughness','partRoughnessValue'],['metallic','partMetallicValue'],['transmission','partTransmissionValue']]){
    const common=commonMaterialValue(materials,field),linked=materials.some(material=>material.linked?.[field]);
    $(labelId).textContent=`当前：${common.label}${linked?' · 节点/贴图驱动，所列为输入默认值':''}`;
  }
  $('partIorValue').textContent=commonMaterialValue(materials,'ior').label;
  const warnings=[...new Set(materials.flatMap(material=>material.warnings || []))];
  const textures=[...new Set(materials.flatMap(material=>(material.textures || []).map(texture=>typeof texture==='string'?texture:texture.name)).filter(Boolean))];
  $('partMaterialResources').innerHTML=(textures.length?`<p>已关联贴图：${textures.map(esc).join('、')}</p>`:'')+warnings.map(warning=>`<p>${esc(warning)}</p>`).join('');
  let note='手动材质编辑不需要 API Key。未勾选的参数与贴图保持原样。';
  if(dirty)note='右侧方案有未保存调整，请先保存并重新预览后编辑部件。';
  else if(currentOutput && currentOutput.version!==current?.version)note='当前图片属于旧方案，请先生成最新预览。';
  else if(feedbackPoints.some(point=>point.pending))note='正在读取实际表面与材质，请稍候。';
  else if(feedbackPoints.some(point=>!point.hit || !point.material_name))note='请移除未命中产品或没有可编辑材质的点。';
  else if(!selected.length)note='先点击预览中的一个或多个部件。';
  const unsupported=materials.some(material=>material.editable===false || material.supported===false);
  const explicitPreset=partMaterialFields.has('preset') && !!presets[$('partPreset').value];
  if(unsupported && !partSelectionBlocked())note='所选材质含复杂或不支持的着色器，不能直接覆盖参数。请明确选择内置材质预设后再修改。';
  $('partMaterialState').textContent=note;
  const blocked=partSelectionBlocked();
  for(const [id,use] of Object.values(partFieldControls)){$(id).disabled=blocked;$(use).disabled=blocked;}
  $('partMaterialSubmit').disabled=blocked || !partMaterialFields.size || (unsupported && !explicitPreset);
  $('partMaterialSubmit').textContent=busy?'正在应用…':'应用材质并重新预览';
  const overrides=current?.plan?.object_material_overrides || [];
  $('partMaterialReset').disabled=blocked || !selected.some(point=>overrides.some(item=>item.object_name===point.object_name && item.material_name===point.material_name));
}
function gatherPartMaterialPatch() {
  const patch={};
  for(const field of partMaterialFields){
    const input=$(partFieldControls[field][0]);
    if(field==='preset'){
      if(!presets[input.value])throw new Error('请选择要应用的材质预设，或取消勾选。');
      patch[field]=input.value;
    }else if(field==='color'){
      if(commonMaterialValue(uniqueMaterialSelections().map(point=>point.material_info || {}),'color').value===null && !partMaterialValueFields.has('color'))throw new Error('所选部件颜色为混合或未知值，请先选择要应用的目标颜色。');
      if(!/^#[0-9a-f]{6}$/i.test(input.value))throw new Error('请选择有效颜色。');
      patch[field]=input.value;
    }else{
      if(input.value.trim()==='')throw new Error('请填写要修改的数值，混合值不会自动覆盖。');
      const value=Number(input.value);if(!Number.isFinite(value) || value<0 || value>1)throw new Error('材质数值必须在 0–1 之间。');
      patch[field]=value;
    }
  }
  return patch;
}
async function submitPartMaterial(reset=false) {
  if(partSelectionBlocked() || !feedbackSource || (!reset && $('partMaterialSubmit').disabled))return;
  let patch={};try{if(!reset)patch=gatherPartMaterialPatch();}catch(error){$('partMaterialError').textContent=error.message;return;}
  if(!reset && !Object.keys(patch).length)return;
  const source=clone(feedbackSource),points=feedbackPoints.map(({id,x,y})=>({id,x,y}));
  if(source.projectId!==current.id || source.key!==sceneOutputKey(currentOutput))return toast('图片已改变，请重新选择部件。',true);
  busy=true;$('partMaterialError').textContent='';renderProject();
  try{
    const result=await api(`/api/projects/${source.projectId}/materials/selection/apply`,{method:'POST',body:{...source.snapshot,points,...(reset?{reset:true}:{patch})}});
    if(current?.id===source.projectId){current=result;syncSettings();clearFeedback(true);}
    toast(reset?'所选部件局部材质已恢复，正在重新预览。':'部件材质已保存，正在真实重新渲染当前镜头。');
  }catch(error){$('partMaterialError').textContent=error.message;}
  finally{busy=false;renderProject();}
}
async function requestRealismReview(event) {
  event.preventDefault();if(comparePrevious || realismBusy || busy || !currentOutput || activeJob() || automaticMaterialBusy())return;
  const projectId=current.id,source=feedbackSnapshot(),key=sceneOutputKey(currentOutput),question=$('realismQuestion').value.trim() || '为什么现在渲染得不够逼真？请根据这张实际预览说明证据、原因和改进建议。';
  realismBusy=true;$('realismAskError').textContent='';renderReview();
  try{
    const result=await api(`/api/projects/${projectId}/review`,{method:'POST',body:{...source,question}});
    if(current?.id===projectId){current=result;try{system=await api('/api/system');}catch(_){}renderProject();if(currentOutput && sceneOutputKey(currentOutput)===key)setInspectorTab('review');}
    toast((result.jobs || []).some(job=>['queued','running'].includes(job.status))?'诊断已更新，正在执行自动优化。':'诊断已更新；本次没有启动自动修改。');
  }catch(error){$('realismAskError').textContent=error.message;}
  finally{realismBusy=false;renderReview();}
}
async function addFeedbackPoint(point) {
  if(comparePrevious || !feedbackMode || !currentOutput || busy || activeJob())return;
  if(feedbackPoints.length>=12)return toast('一次最多选择 12 个位置，可移除不需要的位置。',true);
  if(!point || !Number.isFinite(point.x) || !Number.isFinite(point.y) || point.x<0 || point.x>1 || point.y<0 || point.y>1)return toast('请选择图片范围内的位置。',true);
  if(!feedbackSource)feedbackSource={projectId:current.id,key:sceneOutputKey(currentOutput),snapshot:feedbackSnapshot()};
  const epoch=feedbackEpoch,source=clone(feedbackSource),id=crypto.randomUUID();
  feedbackPoints.push({...point,id,pending:true});$('feedbackError').textContent='';renderFeedback();
  try{
    const response=await api(`/api/projects/${source.projectId}/feedback/pick`,{method:'POST',body:{...source.snapshot,points:[{...point,id}]}});
    if(epoch!==feedbackEpoch || feedbackSource?.key!==source.key)return;
    const target=feedbackPoints.find(entry=>entry.id===id),hit=response.hits?.find(entry=>entry.id===id);
    if(target){Object.assign(target,hit || {hit:false,message:'未收到场景定位结果'}, {pending:false});$('feedbackAnnouncement').textContent=target.hit?`已选择 ${target.object_name || '产品部件'}`:target.message || '没有命中产品';}
  }catch(error){if(epoch===feedbackEpoch){const target=feedbackPoints.find(entry=>entry.id===id);if(target)Object.assign(target,{pending:false,hit:false,error:error.message});$('feedbackAnnouncement').textContent='位置定位失败：'+error.message;}}
  finally{if(epoch===feedbackEpoch)renderFeedback();}
}
async function submitFeedback(event) {
  event.preventDefault();if($('feedbackSubmit').disabled || !feedbackSource)return;
  if(comparePrevious)return;
  if(dirty || !currentOutput || currentOutput.version!==current.version || feedbackSource.projectId!==current.id || feedbackSource.key!==sceneOutputKey(currentOutput))return toast('图片或方案已改变，请生成最新预览后重新点选。',true);
  const text=$('feedbackText').value.trim();if(!text)return;
  const source=clone(feedbackSource),points=feedbackPoints.map(({id,x,y})=>({id,x,y}));
  busy=true;renderProject();$('feedbackError').textContent='';
  try{
    const result=await api(`/api/projects/${source.projectId}/feedback`,{method:'POST',body:{...source.snapshot,points,text}});
    if(current?.id===source.projectId){current=result;syncSettings();clearFeedback(true);}
    toast('修改已记录，正在真实重新渲染所选镜头。');
  }catch(error){$('feedbackError').textContent=error.message;}
  finally{busy=false;renderProject();}
}
function renderReview() {
  updateVisionStatus();
  $('realismAskPanel').hidden=!currentOutput;
  $('realismAskSubmit').disabled=comparePrevious || realismBusy || busy || !!activeJob() || automaticMaterialBusy() || !currentOutput;
  $('realismAskSubmit').textContent=realismBusy?'正在检查…':currentOutput && currentOutput.version===current?.version?'检查并优化':'重新诊断';
  const vision=visionState();
  const missingVision=vision.status==='disabled'?'视觉分析已关闭':vision.status==='missing_key'?'视觉模型缺少 Key':vision.status==='missing_model'?'视觉模型名称未填写':'视觉模型未配置';
  $('realismAskHint').textContent=comparePrevious?'正在对比历史预览，请返回最新图片后再检查或修改。':!vision.attemptable?missingVision+'；当前只能进行基础规则检查。':vision.status==='error'?'视觉模型最近一次调用失败；重新检查会再次尝试，失败时使用基础规则。':vision.status==='configured'?'视觉模型已配置但尚未验证；检查时会尝试连接。':'结合实际图片检查问题；当前版本会尝试自动优化，历史版本只做诊断。';
  const review=currentOutput?.review,corrections=currentOutput?.corrections;
  $('reviewPanel').hidden=!review && !corrections?.length;
  $('reviewEmptyState').hidden=!!review || !!corrections?.length;
  $('reviewEmptyState').textContent=currentOutput?'这张预览尚无诊断。可在下方描述问题。':'生成真实预览后，应用会自动检查并尝试优化。';
  if($('reviewPanel').hidden)return;
  // A new report never opens detailed evidence or moves the preview.
  const description=review?.summary || review?.message || ({passed:'本轮检查通过',manual_review:'有问题待处理',unavailable:'检查暂不可用'}[review?.status]) || '已有检查记录';
  $('reviewSummary').textContent=String(description);
  $('reviewRealismSummary').hidden=!review?.realism?.summary;
  if($('reviewRealismSummary').dataset?.summary!==review?.realism?.summary){
    $('reviewRealismSummary').innerHTML=review?.realism?.summary?`<p class="diagnosis-brief">${esc(review.realism.summary)}</p><details><summary>展开诊断结论</summary><p>${esc(review.realism.summary)}</p></details>`:'';
    if($('reviewRealismSummary').dataset)$('reviewRealismSummary').dataset.summary=review?.realism?.summary || '';
  }
  const issues=Array.isArray(review?.issues)?review.issues:[];
  const realism=review?.realism;
  const causes=Array.isArray(realism?.causes)?realism.causes:[];
  const priorities=Array.isArray(realism?.priority_actions)?realism.priority_actions:[];
  const realismHtml=realism?`<section class="realism-report"><h3>逼真度诊断</h3>${review.mode==='diagnostic_only'?'<p>此份报告记录图片诊断；后续处理以实际任务状态为准。</p>':''}<p>${esc(realism.summary || '当前没有足够证据判断整体逼真度。')}</p>${causes.length?`<div class="realism-causes">${causes.map(cause=>`<article><div><strong>${esc(cause.aspect || '待检查因素')}</strong>${typeof cause.confidence==='number'?`<small>判断置信度 ${Math.round(Math.max(0,Math.min(1,cause.confidence))*100)}%</small>`:''}</div><p><span>画面证据</span>${esc(cause.evidence || '没有提供明确画面证据')}</p><p><span>改进建议</span>${esc(cause.suggestion || '请进一步核对模型与参考信息')}</p>${cause.requires_user?'<small class="realism-manual">可能需要手动调整模型</small>':''}</article>`).join('')}</div>`:''}${priorities.length?`<h4>优先处理</h4><ol>${priorities.map(action=>`<li>${esc(typeof action==='string'?action:JSON.stringify(action))}</li>`).join('')}</ol>`:''}</section>`:'';
  const attempts=Array.isArray(corrections)?corrections:[],chosen=attempts.find(round=>round.applied);
  const detailsKey=JSON.stringify([review,corrections,currentOutput?.effective_plan]);
  if(reviewSeenKey!==detailsKey){reviewSeenKey=detailsKey;$('reviewDetails').innerHTML=`<p>${review?.source==='ai'?'AI 视觉检查':review?.source==='rules'?'基础规则检查':'检查来源未记录'}${chosen?' · 本轮最佳：第 '+Number(chosen.round)+' 轮（0 为初始预览）':''}</p>${realismHtml}${issues.length?`<ul>${issues.map(issue=>`<li>${esc(typeof issue==='string'?issue:issue.description || issue.message || JSON.stringify(issue))}</li>`).join('')}</ul>`:''}${attempts.length?`<div class="review-attempts">${attempts.map(round=>`<div>${round.png_url?`<a href="${esc(round.png_url)}" target="_blank" rel="noopener"><img src="${esc(round.png_url)}" alt="第 ${Number(round.round)} 轮真实预览" loading="lazy"></a>`:''}<span>第 ${Number(round.round)} 轮${round.applied?(currentOutput?.review_applied?' · 已应用至当前版本':' · 本轮最佳'):''}</span><small>曝光 ${esc(round.exposure)} EV · 柔和度 ${esc(round.light_softness)}</small></div>`).join('')}</div>`:''}<details><summary>完整检查与修正记录</summary><pre>${esc(JSON.stringify({review,corrections,effective_plan:currentOutput?.effective_plan},null,2))}</pre></details>`;
  }
}

function renderShots() {
  $('shotCount').textContent=`${shots().length} 个镜头`;
  $('shotHint').textContent = shots().length < 6 ? `当前方案包含 ${shots().length} 个镜头；选择需要的图片` : '选择需要预览或导出的镜头';
  $('shotList').innerHTML=shots().map((s,i) => {const o=latestOutput(s.id);return `<div class="shot-card ${s.id===activeShot?'active':''}"><button type="button" data-shot="${esc(s.id)}" aria-label="查看${esc(s.label)}">${o?`<img src="${esc(o.jpg_url || o.png_url)}" alt="${esc(s.label)}的真实渲染" loading="lazy">`:(s.kind==='detail'?'⌕':'◇')}</button><label title="选择${esc(s.label)}"><input type="checkbox" data-select-shot="${esc(s.id)}" aria-label="选择${esc(s.label)}" ${selectedShots.has(s.id)?'checked':''}></label><strong>${String(i+1).padStart(2,'0')} ${esc(s.label)}</strong><small>${o ? `${o.quality==='preview'?'预览':'4K'} · v${o.version}` : s.kind==='detail'?'细节镜头':'完整构图'}</small></div>`;}).join('');
  $('selectAllShots').checked=selectedShots.size===shots().length;$('selectAllShots').indeterminate=selectedShots.size>0 && selectedShots.size<shots().length;
  $('renderSelection').textContent=`已选 ${selectedShots.size} 张 · 真实 Cycles 渲染`;
}
function renderJob() {
  const logWasOpen = !!$('jobPanel').querySelector('details[open]');
  const jobs=[...(current.jobs || [])].sort((a,b)=>(b.created_at || 0)-(a.created_at || 0));const job=activeJob() || jobs[0];
  $('jobPanel').hidden=!job;if (!job) return;
  const running=['running','queued'].includes(job.status),autoRunning=!running && automaticMaterialBusy();const done=job.status==='completed' && !autoRunning;const cancelled=['cancelled','interrupted'].includes(job.status);
  const total=job.shot_ids?.length || 1;const completed=job.completed?.length || 0;
  const sample=job.sample_progress;
  const automaticTask=(materialAgentRecords.get(current.id) || []).find(materialTaskIsActive);
  let stage=autoRunning?(automaticTask?.stage || current.auto_material?.stage || '正在自动优化材质'):job.stage || statusNames[job.status];if(job.kind==='analyze')stage='模型分析 · '+stage;
  $('jobPanel').className='job-panel'+(job.status==='failed'?' failed':'')+(done?' is-complete':'');
  $('jobPanel').innerHTML=`<div class="job-top"><div><strong>${esc(stage)}</strong><small>${autoRunning?'当前图片暂时保留，自动应用并重渲染后更新':`${job.current_shot?esc(job.current_shot)+' · ':''}${job.kind==='analyze'?'读取几何、部件与贴图':`图组进度 ${completed}/${total} 张${running && sample ? ' · 当前镜头采样 '+sample+'%' : ''}`}${done?' · 执行完成':''}${cancelled?' · 已完成图片保留':''}`}</small></div>${running?`<button type="button" class="button subtle" data-cancel="${esc(job.id)}">取消任务</button>`:autoRunning && (automaticTask?.id || current.auto_material?.task_id)?`<button type="button" class="button subtle" data-cancel-auto-material="${esc(automaticTask?.id || current.auto_material.task_id)}">取消优化</button>`:!done && !autoRunning?`<button type="button" class="button secondary" data-retry="${esc(job.id)}">继续 / 重试</button>`:''}</div>${running?`<div class="progress-track" role="progressbar" aria-label="已完成镜头进度" aria-valuenow="${Number(job.progress)||0}" aria-valuemin="0" aria-valuemax="100"><span style="width:${Math.min(100,Math.max(0,Number(job.progress)||0))}%"></span></div>`:''}${job.error?`<p class="job-error">${esc(job.error)}</p>`:''}<details class="job-log"><summary>查看真实执行日志</summary><pre>${esc((job.log_tail || []).join('\n'))}</pre></details>`;
  if (logWasOpen) $('jobPanel').querySelector('details').open = true;
}
function renderInspection() {
  const openSections = [...$('inspectionContent').querySelectorAll('details')].map(d => d.open);
  const a=current.analysis;const warnings=[...new Set([...(a?.warnings || []),...(current.plan?.pending || []),...(currentOutput?.checks?.manual_review || [])])];
  $('warningBadge').textContent=warnings.length?` · ${warnings.length} 项待确认`:'';
  if (!a) {$('inspectionContent').innerHTML='<p>模型检查尚未完成，请查看任务状态。</p>';return;}
  const f=a.features || {};const dim=current.plan.dimensions_mm?current.plan.dimensions_mm.join(' × ')+' mm（用户指定）':a.dimensions?.unit==='m'?a.dimensions.value.map(n=>(n*1000).toFixed(1)).join(' × ')+' mm（模型声明，需确认）':'未知；使用归一化工作尺度';
  const features=[f.elongated?'细长物体':null,f.flat?'扁平物体':null,f.multipart?'多部件':'单网格',f.has_animation?'已有动画':null,f.has_armature?'已有绑定':null].filter(Boolean);
  $('inspectionContent').innerHTML=`<dl><dt>模型特征</dt><dd>${esc(features.join(' / '))}</dd><dt>真实尺寸</dt><dd>${esc(dim)}</dd><dt>方案来源</dt><dd>${esc(describeSource(current.plan.source))}</dd><dt>材质说明</dt><dd>${esc(current.metadata?.material_note || '未补充')}</dd></dl>${warnings.map(w=>`<p class="warning">• ${esc(w)}</p>`).join('')}<h3>部件层级</h3><table><thead><tr><th>部件</th><th>父部件</th><th>UV / 面数</th></tr></thead><tbody>${(a.objects || []).map(o=>`<tr><td>${esc(o.name)}</td><td>${esc(o.parent || '根节点')}</td><td>${esc(Array.isArray(o.uv_layers)?o.uv_layers.join(', ') || '无 UV':o.uv_layers || '—')} / ${esc(o.faces ?? o.polygons ?? '—')}</td></tr>`).join('')}</tbody></table>${currentOutput?`<details><summary>当前图片的检查结果</summary><pre>${esc(JSON.stringify({checks:currentOutput.checks,image_metrics:currentOutput.metrics},null,2))}</pre></details>`:''}<h3>操作记录</h3>${current.history?.length?current.history.slice().reverse().slice(0,8).map(h=>`<p>v${h.version} · ${esc(h.reason)} · ${new Date(h.at*1000).toLocaleString('zh-CN')}</p>`).join(''):'<p>初始方案；尚未修改参数。</p>'}<details><summary>查看可复现拍摄方案 JSON</summary><pre>${esc(JSON.stringify(current.plan,null,2))}</pre></details>`;
  $('inspectionContent').querySelectorAll('details').forEach((d,i) => d.open = !!openSections[i]);
}
function renderProject() {
  if (!current) return;
  $('welcomePanel').hidden=true;$('projectPanel').hidden=false;$('emptySettings').hidden=true;$('settingsForm').hidden=false;
  $('settingsForm').inert = !current.analysis;
  $('projectTitle').textContent=current.name;$('projectSubtitle').textContent='摄影项目';$('planVersion').textContent='方案 v'+current.version;
  $('undoButton').disabled=busy || !current.history?.length || !!activeJob() || automaticMaterialBusy();$('bundleButton').classList.toggle('disabled',!current.outputs?.length);$('bundleButton').setAttribute('aria-disabled',!current.outputs?.length);$('bundleButton').href=`/api/projects/${current.id}/bundle`;
  if (!dirty && syncSignature!==`${current.id}:${current.version}:${!!current.analysis}`)syncSettings();
  const disabled=busy || !!activeJob() || automaticMaterialBusy() || !current.analysis || !selectedShots.size;
  $('previewButton').disabled=disabled;$('renderButton').disabled=disabled;$('emptyPreview').disabled=disabled;
  $('instructionForm').querySelector('button').disabled=busy || !!activeJob() || automaticMaterialBusy() || !current.analysis;
  updateAiMode();
  const step=!current.analysis?0:!current.outputs?.length?1:current.outputs.some(o=>o.quality!=='preview')?3:2;
  document.querySelectorAll('.workflow>span').forEach((el,i)=>el.classList.toggle('current',i===step));
  renderViewer();renderShots();renderJob();renderInspection();renderSceneExports();
}
async function refreshList() { allProjects=await api('/api/projects');allProjects.sort((a,b)=>(b.created_at || 0)-(a.created_at || 0));renderLibrary(); }
async function openProject(id) {
  if (dirty) {toast('请先保存当前方案，或回退未保存的调整后切换项目。',true);return;}
  try {current=await api('/api/projects/'+id);const savedShot=localStorage.getItem('wuying-shot-'+id);activeShot=current.plan.shots.some(s=>s.id===savedShot)?savedShot:current.plan.style==='dark' && current.plan.shots.some(s=>s.id==='campaign')?'campaign':current.plan.shots[0]?.id;styleFocusNotice='';comparePrevious=false;viewerLatestKey='';selectedShots=new Set(current.plan.shots.map(s=>s.id));selectedMaterial=null;cameraShot=null;syncSignature='';syncSettings();renderProject();setInspectorTab(current.outputs?.length?'review':'plan');renderLibrary();localStorage.setItem('wuying-project',id);await refreshMaterialTasks(id);}
  catch(e){toast(e.message,true);}
}
async function poll() {
  if (polling || !current || busy) return;polling=true;
  try {const id=current.id;const p=await api('/api/projects/'+id);if(current?.id===id){const priorOutputs=current.outputs?.length,priorStyle=current.plan.style;current=p;if(!dirty)focusStyleShot(p.plan.style,priorStyle);if(priorOutputs!==p.outputs?.length){try{system=await api('/api/system');}catch(_){}}renderProject();await refreshMaterialTasks(id);if(priorOutputs!==p.outputs?.length)await refreshList();}if(serviceDisconnected){system=await api('/api/system');$('systemLabel').textContent=system.available?'本机 Blender 已就绪':'未找到 Blender';document.querySelector('.system-status .status-dot').style.background=system.available?'var(--green)':'var(--amber)';serviceDisconnected=false;}}
  catch(e){serviceDisconnected=true;$('systemLabel').textContent='本机服务连接中断';document.querySelector('.system-status .status-dot').style.background='var(--amber)';}
  finally {polling=false;}
}
async function run(kind) {
  if (!current || busy || activeJob() || automaticMaterialBusy()) return;if(!selectedShots.size)return toast('请先选择至少一个镜头。',true);
  busy=true;renderProject();
  try {await savePlan(true);await api(`/api/projects/${current.id}/jobs`,{method:'POST',headers:{'Idempotency-Key':crypto.randomUUID()},body:{kind,quality:kind==='preview'?'preview':$('quality').value,shot_ids:[...selectedShots]}});current=await api('/api/projects/'+current.id);toast(kind==='preview'?'已提交真实预览任务。':'已提交原生 4K 渲染任务。');}
  catch(e){toast(e.message,true);}finally{busy=false;renderProject();}
}
async function applyInstructionAndPreview(event) {
  event.preventDefault();const text=$('instructionInput').value.trim();
  if(!text || !current || busy || activeJob() || automaticMaterialBusy())return;
  const projectId=current.id;let saved=false;
  busy=true;renderProject();
  try{
    await savePlan(true);if(current?.id!==projectId)return;
    const previousStyle=current.plan.style,requestedShots=[...selectedShots];
    const updated=await api(`/api/projects/${projectId}/instruct`,{method:'POST',body:{text}});saved=true;
    let previewShots=requestedShots.filter(id=>updated.plan.shots.some(s=>s.id===id));
    if(current?.id===projectId){current=updated;syncSettings();focusStyleShot(current.plan.style,previousStyle);previewShots=[...selectedShots].filter(id=>updated.plan.shots.some(s=>s.id===id));$('instructionInput').value='';}
    if(!previewShots.length)previewShots=[updated.plan.shots[0].id];
    await api(`/api/projects/${projectId}/jobs`,{method:'POST',headers:{'Idempotency-Key':crypto.randomUUID()},body:{kind:'preview',quality:'preview',shot_ids:previewShots}});
    const refreshed=await api('/api/projects/'+projectId);if(current?.id===projectId)current=refreshed;
    toast('修改已应用，正在重新生成预览；完成后主图自动更新。');
  }catch(error){toast((saved?'参数已保存，但预览未启动：':'')+error.message,true);}
  finally{busy=false;renderProject();}
}
function addFiles(files) {
  const existing=new Set(uploadFiles.map(f=>f.webkitRelativePath || f._relativePath || f.name));for(const f of files){const path=f.webkitRelativePath || f._relativePath || f.name;if(!existing.has(path)){uploadFiles.push(f);existing.add(path);}}
  $('chosenFiles').innerHTML=uploadFiles.map((f,i)=>`<div><span>${esc(f.webkitRelativePath || f._relativePath || f.name)}</span><span>${filenameSize(f.size)} <button type="button" data-remove-file="${i}" aria-label="移除${esc(f.name)}">×</button></span></div>`).join('');$('uploadSubmit').disabled=!uploadFiles.length;
}
async function readEntry(entry,path='') {
  if (entry.isFile) return new Promise((resolve,reject)=>entry.file(f=>{f._relativePath=path+f.name;resolve([f]);},reject));
  if (entry.isDirectory) {const reader=entry.createReader();let entries=[],batch;do {batch=await new Promise((resolve,reject)=>reader.readEntries(resolve,reject));entries.push(...batch);}while(batch.length);return (await Promise.all(entries.map(e=>readEntry(e,path+entry.name+'/')))).flat();}return [];
}
function showUpload() {$('uploadError').textContent='';$('uploadDialog').showModal();}
function setInspectorTab(tab) {
  if(!['review','material','plan'].includes(tab))return;
  if(tab!==inspectorTab){inspectorScrollPositions[inspectorTab]=$('inspectorBody').scrollTop || 0;$('inspectorBody').scrollTop=inspectorScrollPositions[tab] || 0;}
  inspectorTab=tab;
  for(const name of ['review','material','plan']){
    const button=$('inspector'+name[0].toUpperCase()+name.slice(1)+'Tab');
    button.setAttribute('aria-selected',name===tab);button.tabIndex=name===tab?0:-1;
    $('inspector'+name[0].toUpperCase()+name.slice(1)).hidden=name!==tab;
  }
  if(tab==='material' && currentOutput && !feedbackMode){feedbackMode=true;renderFeedback();}
}
function storeMaterialTask(projectId,task) {
  materialAgentRecords.set(projectId,[task,...(materialAgentRecords.get(projectId) || []).filter(item=>item.id!==task.id)]);
}
async function refreshMaterialTasks(projectId) {
  try{
    const tasks=await api(`/api/projects/${projectId}/material-agent/tasks`);
    materialAgentRecords.set(projectId,Array.isArray(tasks)?tasks:[]);
    if(current?.id===projectId)renderMaterialAgent();
  }catch(error){if(current?.id===projectId)$('materialAgentError').textContent='无法读取材质搜索任务：'+error.message;}
}
function materialTaskIsActive(task) {return ['queued','running','rendering'].includes(task.status);}
function automaticMaterialBusy() {
  return ['queued','running','rendering','searching','downloading','applying'].includes(current?.auto_material?.status) || (materialAgentRecords.get(current?.id) || []).some(materialTaskIsActive);
}
function materialSourceLink(url) {
  try{const parsed=new URL(url);return parsed.protocol==='https:' && ['polyhaven.com','www.polyhaven.com','creativecommons.org'].includes(parsed.hostname)?parsed.href:null;}catch(_){return null;}
}
function renderAutomaticMaterialStatus(records) {
  const automatic=current?.auto_material,running=activeJob(),task=records.find(t=>t.origin==='automatic' && materialTaskIsActive(t));
  const newPreview=running?.kind==='preview' && !String(running.request_key || '').startsWith('material-agent:') && !records.some(t=>t.job_id===running.id) && running.id!==automatic?.origin_job_id;
  let stage,notice='自动定位部件、寻找适用的 CC0 表面贴图并重新渲染；保留原色和标识。';
  if(newPreview && current?.plan?.visual_review!==false && current?.plan?.max_corrections!==0 && visionState().attemptable && visionState().status!=='error')stage='当前预览完成后自动检查材质';
  else if(task)stage=task.stage;
  else if(automatic && !newPreview){
    stage=automatic.stage || ({completed:'自动材质优化已完成',unchanged:'本轮保留现有材质',disabled:'自动材质优化已关闭',reverted:'已恢复优化前的材质与图片',needs_attention:'自动材质优化已结束，仍有待检查项',failed:'本轮材质优化未完成',skipped:'本轮保留现有材质',cancelled:'自动材质优化已取消',interrupted:'自动材质优化已中断'}[automatic.status] || '自动检查材质');
    const unique=new Set([stage.trim()]);
    notice=[automatic.error,automatic.notice,...(Array.isArray(automatic.notes)?automatic.notes:[])].filter(value=>{
      if(typeof value!=='string' || !value.trim() || unique.has(value.trim()))return false;unique.add(value.trim());return true;
    }).join('；');
  }
  else if(current?.plan?.visual_review===false || current?.plan?.max_corrections===0){stage='自动材质优化已关闭';notice='可在摄影方案中开启自动检查，并设置至少一轮自动修正。';}
  else if(!visionState().attemptable || visionState().status==='error'){stage='等待可用的 AI 视觉检查';notice=visionState().status==='error'?'视觉模型最近一次调用失败，下次检查会重试；无法分析时保留现有材质。':'视觉模型未配置时保留现有材质，基础渲染照常完成。';}
  else{stage=activeJob()?'预览完成后自动检查材质':'下一次生成预览时自动检查材质';}
  $('autoMaterialStage').textContent=stage || '自动检查材质';$('autoMaterialNotice').textContent=notice;$('autoMaterialNotice').hidden=!notice;
}
function renderMaterialAgent() {
  if(materialAgentProjectId!==current?.id){materialAgentProjectId=current?.id || '';materialAgentRenderedKey='';$('materialAgentPrompt').value='';$('materialAgentColor').checked=false;$('materialAgentError').textContent='';}
  const records=materialAgentRecords.get(current?.id) || [],running=records.some(materialTaskIsActive),selected=uniqueMaterialSelections();
  renderAutomaticMaterialStatus(records);
  const blocked=partSelectionBlocked() || materialAgentSubmitting || running;
  $('materialAgentSubmit').disabled=blocked;
  $('materialAgentSubmit').textContent=materialAgentSubmitting?'正在提交…':running?'材质助手正在处理…':'寻找材质并应用';
  $('materialAgentPrompt').disabled=materialAgentSubmitting || running;
  $('materialAgentColor').disabled=materialAgentSubmitting || running;
  $('materialAgentHint').textContent=running?'按实际执行显示进度；下载后应用到所选部件，并重新渲染当前镜头。':dirty?'请先保存方案并生成新预览。':currentOutput && currentOutput.version!==current?.version?'这张图片已过期，请先生成最新预览。':selected.length?`已选 ${selected.length} 个部件材质。搜索 CC0 资源，下载并应用；默认保留原色和图案。`:'先在预览中点选一个或多个部件。仅对所选部件寻找并应用材质。';
    const statuses={queued:'等待执行',running:'正在寻找与应用',rendering:'真实预览中',completed:'预览已完成',failed:'需要处理',cancelled:'已取消',interrupted:'已中断'};
  const renderKey=JSON.stringify([current?.id,records]);
  if(materialAgentRenderedKey===renderKey)return;materialAgentRenderedKey=renderKey;
  const disclosure=(key)=>`data-material-detail="${esc(key)}" data-material-project="${esc(current?.id)}" ${materialAgentDisclosures.get(current?.id+':'+key)?'open':''}`;
  const taskHtml=task=>{
    const source=task.selection,sourceUrl=materialSourceLink(source?.url),licenseUrl=materialSourceLink(source?.license_url);
    return `<article class="material-agent-task ${['failed','interrupted'].includes(task.status)?'is-failed':''}"><div><strong>${task.origin==='automatic'?'自动 · ':''}${esc(statuses[task.status] || task.status)}</strong>${materialTaskIsActive(task)?`<button type="button" class="text-button" data-cancel-material="${esc(task.id)}">取消</button>`:''}</div><p>${esc(task.stage || '')}</p>${source?`<p>${sourceUrl?`<a href="${esc(sourceUrl)}" target="_blank" rel="noopener noreferrer">${esc(source.name || source.asset_id)}</a>`:esc(source.name || source.asset_id)} · ${licenseUrl?`<a href="${esc(licenseUrl)}" target="_blank" rel="noopener noreferrer">${esc(source.license || '查看许可')}</a>`:esc(source.license || '')}</p>`:''}${task.error?`<p class="error-text">${esc(task.error)}</p>`:''}<details ${disclosure(task.id)}><summary>来源与执行记录</summary><p>${esc(task.prompt)}</p>${source?.reason?`<p>${esc(source.reason)}</p>`:''}<p>${task.use_base_color?'已授权使用资源颜色':'保留原色与图案'}${task.applied_version?' · 方案 v'+Number(task.applied_version):''}</p></details></article>`;
  };
  const latest=records.find(materialTaskIsActive) || records[0],older=records.filter(task=>task.id!==latest?.id);
  $('materialAgentTasks').innerHTML=(latest?taskHtml(latest):'')+(older.length?`<details class="material-agent-history" ${disclosure('history')}><summary>之前的材质任务（${older.length}）</summary>${older.map(taskHtml).join('')}</details>`:'');
}
async function submitMaterialAgent(event) {
  event.preventDefault();if($('materialAgentSubmit').disabled || !feedbackSource || !currentOutput)return;
  const prompt=$('materialAgentPrompt').value.trim();if(!prompt)return;
  const source=clone(feedbackSource);
  if(source.projectId!==current?.id || source.key!==sceneOutputKey(currentOutput))return toast('图片已改变，请重新选择部件。',true);
  const body={...source.snapshot,points:feedbackPoints.map(({id,x,y})=>({id,x,y})),prompt,use_base_color:$('materialAgentColor').checked};
  materialAgentSubmitting=true;$('materialAgentError').textContent='';renderMaterialAgent();
  try{
    const task=await api(`/api/projects/${source.projectId}/material-agent/tasks`,{method:'POST',body});
    storeMaterialTask(source.projectId,task);
    if(current?.id===source.projectId)toast('材质助手已启动，将寻找资源、下载并生成真实预览。');
  }catch(error){if(current?.id===source.projectId)$('materialAgentError').textContent=error.message;}
  finally{materialAgentSubmitting=false;renderMaterialAgent();}
}
function installEvents() {
  document.querySelectorAll('[data-inspector]').forEach(button=>{button.onclick=()=>setInspectorTab(button.dataset.inspector);button.onkeydown=event=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;event.preventDefault();const tabs=['review','material','plan'],index=tabs.indexOf(inspectorTab);const next=event.key==='Home'?tabs[0]:event.key==='End'?tabs[2]:tabs[(index+(event.key==='ArrowRight'?1:2))%3];setInspectorTab(next);document.querySelector('[data-inspector="'+next+'"]').focus();};});
  $('comparePreview').onclick=()=>{comparePrevious=!comparePrevious;feedbackMode=false;renderViewer();renderInspection();};
  $('materialAgentForm').onsubmit=submitMaterialAgent;
  $('materialAgentTasks').addEventListener('toggle',event=>{const target=event.target;if(target.tagName==='DETAILS' && target.dataset.materialDetail)materialAgentDisclosures.set(target.dataset.materialProject+':'+target.dataset.materialDetail,target.open);},true);
  $('materialAgentTasks').onclick=async event=>{const button=event.target.closest('[data-cancel-material]');if(!button || !current)return;button.disabled=true;try{const task=await api(`/api/projects/${current.id}/material-agent/tasks/${button.dataset.cancelMaterial}/cancel`,{method:'POST'});storeMaterialTask(current.id,task);renderMaterialAgent();}catch(error){$('materialAgentError').textContent=error.message;button.disabled=false;}};
  setInspectorTab('review');
  $('aiSettingsButton').onclick=showAiSettings;$('feedbackAiSettings').onclick=showAiSettings;
  $('aiSettingsForm').onsubmit=e=>{e.preventDefault();saveAiSettings(false);};$('aiSaveTest').onclick=()=>saveAiSettings(true);$('visionSaveTest').onclick=()=>saveAiSettings('vision');$('visionEnabled').onchange=renderVisionFields;
  $('aiSettingsDialog').addEventListener('close',()=>{$('aiApiKey').value='';$('aiClearKey').checked=false;$('visionApiKey').value='';$('visionClearKey').checked=false;});
  $('aiClearKey').onchange=()=>{if($('aiClearKey').checked)$('aiApiKey').value='';};
  $('aiApiKey').oninput=()=>{if($('aiApiKey').value)$('aiClearKey').checked=false;};
  $('feedbackToggle').onclick=()=>{feedbackMode=!feedbackMode;if(!feedbackMode)clearFeedback(true);else{setInspectorTab('material');renderFeedback();}};
  $('feedbackClear').onclick=()=>clearFeedback(false);$('feedbackForm').onsubmit=submitFeedback;
  $('partMaterialTab').onclick=()=>{partEditTab='material';renderPartMaterial();};$('partLanguageTab').onclick=()=>{partEditTab='language';renderPartMaterial();};
  for(const [field,[id,use]] of Object.entries(partFieldControls)){
    $(id).addEventListener(field==='preset'?'change':'input',()=>{
      const selected=field!=='preset' || !!$(id).value;
      partMaterialValueFields.add(field);
      $(use).checked=selected;if(selected)partMaterialFields.add(field);else partMaterialFields.delete(field);
      $('partMaterialError').textContent='';renderPartMaterial();
    });
    $(use).onchange=()=>{if($(use).checked)partMaterialFields.add(field);else partMaterialFields.delete(field);$('partMaterialError').textContent='';renderPartMaterial();};
  }
  $('partMaterialForm').onsubmit=event=>{event.preventDefault();submitPartMaterial(false);};$('partMaterialReset').onclick=()=>submitPartMaterial(true);
  $('realismAskForm').onsubmit=requestRealismReview;
  $('feedbackAddPoint').onclick=()=>addFeedbackPoint({x:readNumber('feedbackX')/100,y:readNumber('feedbackY')/100});
  $('renderImage').onclick=e=>{if(comparePrevious || busy || activeJob() || !currentOutput)return;const point=pointFromClient(e.clientX,e.clientY);if(point){feedbackMode=true;setInspectorTab('material');addFeedbackPoint(point);}};
  $('renderImage').addEventListener('load',renderFeedbackMarkers);window.addEventListener('resize',renderFeedbackMarkers);
  const removePoint=e=>{const button=e.target.closest('[data-remove-point]');if(button && !busy){feedbackPoints=feedbackPoints.filter(point=>point.id!==button.dataset.removePoint);renderFeedback();}};
  $('feedbackSelection').onclick=removePoint;$('feedbackMarkers').onclick=removePoint;
  $('newProject').onclick=showUpload;$('uploadMain').onclick=showUpload;
  $('mobileNewProject').onclick=showUpload;
  $('mobileProjectSelect').onchange=async()=>{const id=$('mobileProjectSelect').value;if(id)await openProject(id);$('mobileProjectSelect').value=current?.id || '';};
  document.querySelectorAll('.close-dialog').forEach(b=>b.onclick=()=>b.closest('dialog').close());
  $('sceneExportButton').onclick=showSceneExport;
  $('sceneExportForm').onsubmit=submitSceneExport;
  $('sceneExportSource').onchange=()=>{const output=current?.outputs?.find(item=>sceneOutputKey(item)===$('sceneExportSource').value);sceneExportSource=output?clone(output):null;$('sceneExportError').textContent='';renderSceneExportControls();};
  document.querySelectorAll('[name=sceneExportFormat]').forEach(input=>input.onchange=()=>{$('sceneExportError').textContent='';renderSceneExportControls();});
  $('browseFiles').onclick=e=>{e.stopPropagation();$('modelFiles').click();};$('browseFolder').onclick=e=>{e.stopPropagation();$('modelFolder').click();};$('dropzone').onclick=e=>{if(e.target===$('dropzone') || !e.target.closest('button'))$('modelFiles').click();};$('dropzone').onkeydown=e=>{if(e.key==='Enter' || e.key===' '){e.preventDefault();$('modelFiles').click();}};
  $('modelFiles').onchange=e=>addFiles(e.target.files);$('modelFolder').onchange=e=>addFiles(e.target.files);
  for (const event of ['dragenter','dragover']) $('dropzone').addEventListener(event,e=>{e.preventDefault();$('dropzone').classList.add('dragging');});
  $('dropzone').ondragleave=()=>$('dropzone').classList.remove('dragging');$('dropzone').ondrop=async e=>{e.preventDefault();$('dropzone').classList.remove('dragging');try{const entries=[...e.dataTransfer.items].map(i=>i.webkitGetAsEntry?.()).filter(Boolean);if(entries.length)addFiles((await Promise.all(entries.map(x=>readEntry(x)))).flat());else addFiles(e.dataTransfer.files);}catch(error){$('uploadError').textContent=error.message;}};
  $('chosenFiles').onclick=e=>{const b=e.target.closest('[data-remove-file]');if(b){uploadFiles.splice(Number(b.dataset.removeFile),1);addFiles([]);}};
  $('uploadForm').onsubmit=async e=>{
    e.preventDefault();if(!uploadFiles.length)return;$('uploadSubmit').disabled=true;$('uploadSubmit').textContent='正在上传…';$('uploadError').textContent='';
    try {const form=new FormData($('uploadForm'));uploadFiles.forEach(f=>form.append('files',f));form.append('paths',JSON.stringify(uploadFiles.map(f=>f.webkitRelativePath || f._relativePath || f.name)));const p=await api('/api/projects',{method:'POST',body:form});$('uploadDialog').close();uploadFiles=[];$('uploadForm').reset();addFiles([]);dirty=false;await refreshList();await openProject(p.id);toast('模型已上传，正在由 Blender 检查资源与结构。');}
    catch(error){$('uploadError').textContent=error.message;}finally{$('uploadSubmit').disabled=!uploadFiles.length;$('uploadSubmit').textContent='上传并分析模型';}
  };
  $('projectList').onclick=e=>{const b=e.target.closest('[data-project]');if(b)openProject(b.dataset.project);};
  $('exampleList').onclick=async e=>{const b=e.target.closest('[data-example]');if(!b)return;b.disabled=true;try{const p=await api('/api/examples/'+b.dataset.example+'/import',{method:'POST'});await refreshList();await openProject(p.id);toast('验收模型已导入，正在进行真实分析。');}catch(error){toast(error.message,true);}finally{b.disabled=false;}};
  $('previewButton').onclick=()=>run('preview');$('emptyPreview').onclick=()=>run('preview');$('renderButton').onclick=()=>run('render');
  $('settingsForm').onsubmit=async e=>{e.preventDefault();try{await savePlan();}catch(error){toast(error.message,true);}};
  $('settingsForm').addEventListener('input',e=>{if(['materialSlot','cameraShot','quality','materialOrigin','materialLicense','externalColor','externalRoughness','externalNormal'].includes(e.target.id))return;if(e.target.id==='materialColor' && selectedMaterial)editedMaterialColors.add(selectedMaterial);markDirty();updateRangeLabels();});
  $('settingsForm').addEventListener('change',e=>{if(e.target.matches('[name=aspect]'))updateRangeLabels();if(e.target.matches('[name=style]')){focusStyleShot(e.target.value,draft.style);renderProject();}});
  $('materialSlot').onchange=()=>{stashMaterial();selectedMaterial=$('materialSlot').value;syncMaterial();};
  $('materialPreset').onchange=()=>{const p=$('materialPreset').value;const defaults={matte_plastic:[.5,0,0],glossy_plastic:[.17,0,0],painted_metal:[.28,.7,0],brushed_metal:[.3,1,0],polished_metal:[.09,1,0],glass:[.04,0,1],rubber:[.8,0,0],fabric:[.85,0,0],leather:[.5,0,0],wood:[.45,0,0],ceramic:[.2,0,0]};if(defaults[p])['roughness','metallic','transmission'].forEach((id,i)=>setValue(id,defaults[p][i]));if(!p){editedMaterialColors.delete(selectedMaterial);stashMaterial();syncMaterial();}$('materialEditing').hidden=!p;markDirty();updateRangeLabels();};
  $('cameraShot').onchange=()=>{stashCamera();cameraShot=$('cameraShot').value;syncCamera();};
  document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>{document.querySelectorAll('[data-tab]').forEach(x=>x.setAttribute('aria-selected',x===b));for(const key of ['materials','camera','structure'])$(key+'Tab').hidden=key!==b.dataset.tab;});
  $('shotList').onclick=e=>{const b=e.target.closest('[data-shot]');if(b){stashCamera();activeShot=b.dataset.shot;comparePrevious=false;styleFocusNotice='';localStorage.setItem('wuying-shot-'+current.id,activeShot);cameraShot=activeShot;$('cameraShot').value=cameraShot;syncCamera();renderViewer();renderShots();renderInspection();}};
  $('shotList').onchange=e=>{if(e.target.dataset.selectShot){if(e.target.checked)selectedShots.add(e.target.dataset.selectShot);else selectedShots.delete(e.target.dataset.selectShot);renderProject();}};
  $('selectAllShots').onchange=()=>{selectedShots=$('selectAllShots').checked?new Set(shots().map(s=>s.id)):new Set();renderProject();};
  $('jobPanel').onclick=async e=>{const autoCancel=e.target.closest('[data-cancel-auto-material]');if(autoCancel){try{await api(`/api/projects/${current.id}/material-agent/tasks/${autoCancel.dataset.cancelAutoMaterial}/cancel`,{method:'POST'});await poll();toast('自动优化已取消，已完成图片保留。');}catch(error){toast(error.message,true);}return;}const cancel=e.target.closest('[data-cancel]'),retry=e.target.closest('[data-retry]');if(!cancel && !retry)return;try{const id=cancel?.dataset.cancel || retry.dataset.retry;await api(`/api/jobs/${id}/${cancel?'cancel':'retry'}`,{method:'POST'});await poll();toast(cancel?'已发送取消请求，已完成图片保留。':'正在继续原任务的未完成镜头。');}catch(error){toast(error.message,true);}};
  $('undoButton').onclick=async()=>{try{current=await api(`/api/projects/${current.id}/undo`,{method:'POST'});syncSettings();renderProject();toast('已恢复上一版方案；原始模型保持不变。');}catch(error){toast(error.message,true);}};
  $('instructionForm').onsubmit=applyInstructionAndPreview;
  $('instructionChips').onclick=e=>{if(e.target.tagName==='BUTTON'){$('instructionInput').value=e.target.textContent;$('instructionInput').focus();}};
  $('toggleGrid').onclick=()=>{$('compositionGrid').hidden=!$('compositionGrid').hidden;$('toggleGrid').setAttribute('aria-pressed',!$('compositionGrid').hidden);};
  $('zoomImage').onclick=()=>{if(currentOutput){$('fullImage').src=currentOutput.png_url;$('imageDialog').showModal();}else toast('生成预览后即可查看原图。');};
  $('systemInfo').onclick=async()=>{try{system=await api('/api/system');}catch(error){}$('systemDetails').innerHTML=`<p>${system?.available?'Blender 已就绪':'未找到 Blender，请配置 BLENDER_PATH'}。${system?.ai_mode==='ai'?'AI 服务已配置。':'当前使用内置规则与材质预设，可独立完成基础渲染。'}</p><pre>${esc(JSON.stringify(system,null,2))}</pre>`;$('infoDialog').showModal();};
  $('importMaterial').onclick=async()=>{if(!current || !selectedMaterial)return toast('请先选择一个材质槽。',true);const form=new FormData();form.set('name',selectedMaterial);form.set('preset',$('materialPreset').value || 'matte_plastic');form.set('source',$('materialOrigin').value);form.set('license',$('materialLicense').value);for(const [id,channel]of [['externalColor','base_color'],['externalRoughness','roughness'],['externalNormal','normal']])if($(id).files[0])form.set(channel,$(id).files[0]);try{await savePlan(true);current=await api(`/api/projects/${current.id}/materials/import`,{method:'POST',body:form});syncSettings();renderProject();toast('PBR 贴图已导入，来源与许可已记录。');}catch(error){toast(error.message,true);}};
  window.addEventListener('beforeunload',e=>{if(dirty){e.preventDefault();e.returnValue='';}});
}
async function start() {
  const presetOptions=Object.entries(presets).map(([k,v])=>`<option value="${k}">${v}</option>`).join('');
  $('materialPreset').insertAdjacentHTML('beforeend',presetOptions);$('partPreset').insertAdjacentHTML('beforeend',presetOptions);installEvents();
  const results=await Promise.allSettled([api('/api/system'),refreshList(),api('/api/examples')]);
  if(results[0].status==='fulfilled'){system=results[0].value;$('systemLabel').textContent=system.available?'本机 Blender 已就绪':'未找到 Blender';document.querySelector('.system-status .status-dot').style.background=system.available?'var(--green)':'var(--amber)';}else{serviceDisconnected=true;$('systemLabel').textContent='本机服务连接失败';toast(results[0].reason.message,true);}
  if(results[1].status==='rejected')toast(results[1].reason.message,true);
  if(results[2].status==='fulfilled'){$('exampleList').innerHTML=results[2].value.map((e,i)=>`<button class="example-button" data-example="${esc(e.id)}"><span class="example-icon">${['♧','▱','♜','♧','◇','↻'][i%6]}</span><div><strong>${esc(e.name)}</strong><p>${esc(e.description)}</p></div></button>`).join('');if(!results[2].value.length)$('exampleList').innerHTML='<p class="muted">验收模型尚未安装。请上传自己的模型开始。</p>';}
  const saved=localStorage.getItem('wuying-project');if(saved && allProjects.some(p=>p.id===saved))await openProject(saved);
  setInterval(poll,2000);
}
start().catch(e=>toast(e.message,true));
